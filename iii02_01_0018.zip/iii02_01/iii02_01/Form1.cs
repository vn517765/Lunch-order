﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iii02_01
{
    public partial class TB_userlistSC : Form
    {
        SqlConnectionStringBuilder iii02sc;
        string userid;
        string userneme;
        string sqlcmd;
        int rows;
        int useridindex;
        int shopidindex;
        int menuidindex;
        int orderindex;
        bool userdatecheck=false;
        bool shopdatecheck = false;
        bool menudatecheck = false;


        public TB_userlistSC()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            訂購單infoBindingSource.Filter = "已刪除=0 ";
            this.訂購單infoTableAdapter.Fill(this.iii02_01DataSet.訂購單info);


            訂購單BindingSource.Filter = "已刪除=0";
            this.訂購單TableAdapter.Fill(this.iii02_01DataSet.訂購單);
            餐廳BindingSource.Filter = "已刪除=0";
            this.餐廳TableAdapter.Fill(this.iii02_01DataSet.餐廳);
            菜單infoBindingSource.Filter = "已刪除=0";
            this.菜單infoTableAdapter.Fill(this.iii02_01DataSet.菜單info);
            訂購人BindingSource.Filter = "已刪除=0";
            this.訂購人TableAdapter.Fill(this.iii02_01DataSet.訂購人);
            店家BindingSource.Filter = "已刪除=0";
            this.店家TableAdapter.Fill(this.iii02_01DataSet.店家);
            tabControl_iii.Visible=false;
            iii02sc = new SqlConnectionStringBuilder();
            iii02sc.DataSource = @".";
            iii02sc.InitialCatalog = "iii02_01";
            iii02sc.IntegratedSecurity = true;
        }
        private void bt_login_Click(object sender, EventArgs e)
        {
            if (bt_login.Text=="登入")
            {
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = "select * from 訂購人 where 訂購人編號 = @SearchID";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchID", LB_user.SelectedValue);
                if (LB_user.SelectedValue != null)
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        label1.Text = "使用ID:" + string.Format("{0}", reader["訂購人編號"]) + "登入,成員姓名:" + string.Format("{0}", reader["姓名"]);
                        tabControl_iii.Visible = true;
                        LB_user.Visible = false;
                        userid = string.Format("{0}", reader["訂購人編號"]);
                        userneme = string.Format("{0}", reader["姓名"]);
                        bt_login.Text = "登出";
                        LB_user.Visible = false;
                        label2.Visible = false;
                        TB_userSC.Visible = false;
                        TB_userSC.Text = "";
                    }
                    reader.Close();
                    con.Close();                    
                    sqlcmd = "select * from 訂購人 where 訂購人編號 = " + LB_user.SelectedValue;
                    TB_uselog.AppendText(System.DateTime.Now+":"+"成員" + LB_user.SelectedValue+" "+LB_user.Text+ "登入" + Environment.NewLine);
                }
                else
                {
                    label1.Text = "無此使用者";
                }
            }
            else//登出
            {
                bt_login.Text = "登入";
                tabControl_iii.Visible = false;
                userid = "";
                userneme = "";
                label1.Text = "請雙擊姓名後登入";
                LB_user.Visible = true;
                label2.Visible = true;
                TB_userSC.Visible = true;
                TB_userSC2.Text = "";
                TB_uselog.AppendText(System.DateTime.Now + ":" + "成員" + LB_user.SelectedValue + " " + LB_user.Text + "登出" + Environment.NewLine);
            }


        }





        void userdatenullcheck()//成員資料欄位空值確認
        {
            if ((TB_username.Text!="")&&(TB_usertel.Text !="")&&(TB_useridentity.Text!="")&&(TB_userclassroom.Text!=""))
            {
                userdatecheck = true;
            }
            else
            {
                userdatecheck = false;
                MessageBox.Show(string.Format("姓名/電話/身分別/上課教室 不可填空"));
            }
        }



        private void listBox_userlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LB_userlist.SelectedValue != null)
            {
                TB_uselog.AppendText(System.DateTime.Now + ":"+"選取成員" + LB_userlist.SelectedValue + " " + LB_userlist.Text + Environment.NewLine);
            }
        }

        private void button_userins_Click(object sender, EventArgs e)
        {
            userdatenullcheck();
            if (userdatecheck)
            {
                sqlcmd = "insert into 訂購人 (姓名,電話,身分別,上課地點,備註) values('" + TB_username.Text + "','" + TB_usertel.Text + "','" + TB_useridentity.Text + "','" + TB_userclassroom.Text + "','" + TB_userremark.Text + "')";
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "新增成員" + LB_user.SelectedValue + " " + LB_user.Text + "操作完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();                
                this.訂購人TableAdapter.Fill(this.iii02_01DataSet.訂購人);
                this.訂購人BindingSource.MoveLast();
                
            }
        }

        private void button_userupdata_Click(object sender, EventArgs e)
        {
            userdatenullcheck();
            if (userdatecheck&&(LB_userlist.SelectedValue!=null))
            {
                useridindex = this.訂購人BindingSource.Position;
                sqlcmd = "Update 訂購人 set 姓名='" + TB_username.Text + "',電話='" + TB_usertel.Text + "',身分別='" + TB_useridentity.Text + "',上課地點='" + TB_userclassroom.Text + "',備註='" + TB_userremark.Text + "' where 訂購人編號 = " + LB_userlist.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "修改成員" + LB_user.SelectedValue + " " + LB_user.Text + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.訂購人TableAdapter.Fill(this.iii02_01DataSet.訂購人);
                this.訂購人BindingSource.Position = useridindex;
                
            }


        }

        private void TB_userTBcls_Click(object sender, EventArgs e)
        {
            TB_username.Text = "";
            TB_usertel.Text = "";
            TB_useridentity.Text = "";
            TB_userclassroom.Text = "";
            TB_userremark.Text = "";
            TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "清空成員" + LB_user.SelectedValue + " " + LB_user.Text + "暫存顯示資料" + Environment.NewLine);

        }

        private void button_useridel_Click(object sender, EventArgs e)
        {
            if (LB_userlist.SelectedValue != null)
            {
                string edituserid = LB_user.SelectedValue.ToString();
                string editusermane = LB_user.Text;
                sqlcmd = "Update 訂購人 set 已刪除=1 where 訂購人編號 = " + LB_userlist.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "刪除成員" + edituserid + " " + editusermane + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.訂購人TableAdapter.Fill(this.iii02_01DataSet.訂購人);
                
            }

        }
        
        private void TB_shopTBcls_Click(object sender, EventArgs e)
        {
            店名TextBox.Text = "";
            電話TextBox.Text = "";
            地址TextBox.Text = "";
            備註TextBox.Text = "";
            TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "清空餐廳" + LB_shoplist.SelectedValue + " " + LB_shoplist.Text + "暫存顯示資料" + Environment.NewLine);
        }
        void shopdatenullcheck()//餐廳資料欄位空值確認
        {
            if (店名TextBox.Text != "" && 電話TextBox.Text != "")
            {
                shopdatecheck = true;

            }
            else
            {
                shopdatecheck = false;
                MessageBox.Show(string.Format("店名/電話 不可填空"));
            }
        }
        private void button_shopins_Click(object sender, EventArgs e)
        {
            shopdatenullcheck();
            if (shopdatecheck)
            {
                sqlcmd = "insert into 店家 (店名,電話,地址,備註) values('" + 店名TextBox.Text + "','" + 電話TextBox.Text + "','" + 地址TextBox.Text + "','" + 備註TextBox.Text + "')";
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "新增餐廳" + LB_shoplist.SelectedValue + " " + LB_shoplist.Text + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();                
                this.店家TableAdapter.Fill(this.iii02_01DataSet.店家);
                this.店家BindingSource.MoveLast();

            }
        }
        private void button_shopupdata_Click(object sender, EventArgs e)
        {
            shopdatenullcheck();
            if (shopdatecheck && (LB_shoplist.SelectedValue != null))
            {
                shopidindex = this.店家BindingSource.Position;
                sqlcmd = "Update 店家 set 店名='" + 店名TextBox.Text + "',電話='" + 電話TextBox.Text + "',地址='" + 地址TextBox.Text + "',備註='" + 備註TextBox.Text + "' where 店家編號 = " + LB_shoplist.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                //MessageBox.Show(string.Format("餐廳資料更新完畢,共影響{0}筆", rows));
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "修改餐廳" + LB_shoplist.SelectedValue + " " + LB_shoplist.Text + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.店家TableAdapter.Fill(this.iii02_01DataSet.店家);
                this.店家BindingSource.Position = shopidindex;

            }
        }
        private void button_shopdel_Click(object sender, EventArgs e)
        {
            if (LB_shoplist.SelectedValue != null)
            {
                string edirdshopid = LB_shoplist.SelectedValue.ToString();
                string edirshopname = LB_shoplist.Text;
                sqlcmd = "Update 店家 set 已刪除=1 where 店家編號 = " + LB_shoplist.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "刪除餐廳" + edirdshopid + " " + edirshopname + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.店家TableAdapter.Fill(this.iii02_01DataSet.店家);

            }
        }

        private void TB_userSC_TextChanged(object sender, EventArgs e)
        {
            訂購人BindingSource.Filter = "已刪除=0 and 姓名 like '%" + TB_userSC.Text + "%'";
            TB_uselog.AppendText(System.DateTime.Now + ":搜尋成員姓名包含" + TB_userSC.Text + Environment.NewLine);

        }



        private void TB_userSC2_TextChanged(object sender, EventArgs e)
        {
            訂購人BindingSource.Filter = "已刪除=0 and 姓名 like '%" + TB_userSC2.Text + "%'";
            TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "搜尋成員姓名包含" + TB_userSC2.Text+ Environment.NewLine);
        }

        private void TB_shopSC_TextChanged(object sender, EventArgs e)
        {
            店家BindingSource.Filter = "已刪除=0 and 店名 like '%" + TB_shopSC.Text + "%'";
            TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "搜尋餐廳名稱包含" + TB_shopSC.Text + Environment.NewLine);
        }



        private void LB_menulist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LB_menulist.SelectedValue != null)
            {
                TB_uselog.AppendText(System.DateTime.Now + ":" + "選取菜色" + LB_menulist.SelectedValue + " " + LB_menulist.Text + Environment.NewLine);
                PIC_menu.ImageLocation = 菜色圖片TextBox.Text;
            }

        }

        private void PIC_menu_Click(object sender, EventArgs e)
        {
            if (菜色圖片TextBox.Text !="")
            {
                System.Diagnostics.Process.Start(菜色圖片TextBox.Text);
            }

        }



        private void 菜單圖片TextBox_TextChanged(object sender, EventArgs e)
        {
            店家BindingSource.Filter = "已刪除=0 and 店名 like '%" + TB_shopSC.Text + "%'";
        }

        private void TB_menuCS_TextChanged(object sender, EventArgs e)
        {
            菜單infoBindingSource.Filter = "已刪除=0 and 品名 like '%" + TB_menuCS.Text + "%'";
            TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "搜尋菜色名稱包含" + TB_menuCS.Text + Environment.NewLine);
        }

        private void LB_shoplist_DoubleClick(object sender, EventArgs e)
        {
             tabControl_iii.SelectedTab = tabPage_menu;
        }

        private void LB_menushotlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LB_menushotlist.SelectedValue != null)
            {
                菜單infoBindingSource.Filter = "已刪除=0 and  店家編號=" + LB_menushotlist.SelectedValue;
                this.菜單infoBindingSource.MoveLast();
                訂購單infoBindingSource2.Filter = "已刪除=0 and 訂購提交=0 and  店家編號=" + LB_menushotlist.SelectedValue;


            }

        }

        private void 店名Label3_DoubleClick(object sender, MouseEventArgs e)
        {
            tabControl_iii.SelectedTab = tabPage_shop;
        }

        private void 店名ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LB_shoplist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LB_shoplist != null)
            {
                TB_uselog.AppendText(System.DateTime.Now + ":" + "選取餐廳" + LB_shoplist.SelectedValue + " " + LB_shoplist.Text + Environment.NewLine);
            }
        }

        private void button_menucls_Click(object sender, EventArgs e)
        {
            品名TextBox.Text = "";
            單價TextBox.Text = "";
            供應限制TextBox.Text = "";
            備註TextBox1.Text = "";
            菜色圖片TextBox.Text = "";
            店名Label3.Text = "請選擇店家";
        }
        void menudatenullcheck()
        {
            if (品名TextBox.Text!=""&& 單價TextBox.Text!="")
            {

                menudatecheck = true;

            }
            else
            {
                menudatecheck = false;
                MessageBox.Show(string.Format("品名/單價 不可填空"));

            }
        }


        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)//限制只能輸入數字
        {
            // e.KeyChar == (Char)48 ~ 57 -----> 0~9
            // e.KeyChar == (Char)8 -----------> Backpace
            // e.KeyChar == (Char)13-----------> Enter
            if (e.KeyChar == (Char)48 || e.KeyChar == (Char)49 ||
               e.KeyChar == (Char)50 || e.KeyChar == (Char)51 ||
               e.KeyChar == (Char)52 || e.KeyChar == (Char)53 ||
               e.KeyChar == (Char)54 || e.KeyChar == (Char)55 ||
               e.KeyChar == (Char)56 || e.KeyChar == (Char)57 ||
               e.KeyChar == (Char)13 || e.KeyChar == (Char)8)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

            private void button_menuins_Click(object sender, EventArgs e)
        {
            menudatenullcheck();
            if (menudatecheck)
            {
                sqlcmd = "insert into 菜單 (品名,單價,店家編號,供應限制,菜色圖片,備註) values('" + 品名TextBox.Text + "'," + Convert.ToUInt32(單價TextBox.Text) + "," + LB_menushotlist.SelectedValue + ",'"+供應限制TextBox.Text+"','"+ 菜色圖片TextBox.Text+ "','"+ 備註TextBox.Text + "')";
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "新增菜色" + LB_menulist.SelectedValue + " " + LB_menulist.Text + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.菜單infoTableAdapter.Fill(this.iii02_01DataSet.菜單info);
                this.菜單infoBindingSource.MoveLast();
            }
        }

        private void button_menuupdata_Click(object sender, EventArgs e)
        {
            shopdatenullcheck();
            if (shopdatecheck && (LB_shoplist.SelectedValue != null))
            {
                menuidindex= this.菜單infoBindingSource.Position;
                sqlcmd = "Update 菜單 set 品名='" + 品名TextBox.Text + "',單價=" + Convert.ToUInt32(單價TextBox.Text) + ",店家編號=" + LB_menushotlist.SelectedValue + ",供應限制='" + 供應限制TextBox.Text+ "',菜色圖片='" + 菜色圖片TextBox.Text + "',備註='" +備註TextBox.Text + "' where 品名編號 = " + LB_menulist.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "修改菜色" + LB_menulist.SelectedValue + " " + LB_menulist.Text + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.菜單infoTableAdapter.Fill(this.iii02_01DataSet.菜單info);
                this.菜單infoBindingSource.Position = menuidindex;
            }
        }

        private void button_menudle_Click(object sender, EventArgs e)
        {
            if (LB_shoplist.SelectedValue != null)
            {
                string editmenuid = LB_menulist.SelectedValue.ToString();
                string editmemuname = LB_menulist.Text;
                sqlcmd = "Update 菜單 set 已刪除=1 where 品名編號 = " + LB_menulist.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "刪除菜色" + editmenuid + " " + editmemuname + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                this.菜單infoTableAdapter.Fill(this.iii02_01DataSet.菜單info);
            }
        }

        private void TB_menuCS_TextChanged(object sender, KeyPressEventArgs e)
        {
            菜單infoBindingSource.Filter = "已刪除=0 and 品名 like '%" + TB_menuCS.Text + "%'";
        }

        private void button_orderadd_Click(object sender, EventArgs e)
        {
            if (LB_menulist.SelectedValue != null  && TB_ordercount.Text != "")
            {
                if (LB_訂購單未提交.SelectedValue != null)
                {
                    {//新增訂購單細項加入至同餐廳未提交訂購單編號(訂購單編號ListBox.SelectedValue)
                        sqlcmd = "insert into 訂購單細項 (訂購單編號,訂購人,品名編號,訂購數量) values(" + LB_訂購單未提交.SelectedValue + "," + LB_userlist.SelectedValue + "," + LB_menulist.SelectedValue + "," + Convert.ToInt32(TB_ordercount.Text) + ")";
                        SqlConnection con = new SqlConnection(iii02sc.ToString());
                        con.Open();
                        string strSQL = sqlcmd;
                        SqlCommand cmd = new SqlCommand(strSQL, con);
                        rows = cmd.ExecuteNonQuery();
                        strSQL = "update 訂購單細項 set 訂購單細項.單價=菜單.單價 from 訂購單細項 inner join 菜單 on 訂購單細項.品名編號=菜單.品名編號 where 訂購單細項.單價=0";
                        SqlCommand cmd2 = new SqlCommand(strSQL, con);
                        cmd2.ExecuteNonQuery();
                        con.Close();
                        訂購單BindingSource.Filter = "已刪除=0";
                        this.訂購單TableAdapter.Fill(this.iii02_01DataSet.訂購單);
                        訂購單BindingSource.MoveLast();
                        訂購單infoBindingSource.Filter = "已刪除=0";
                        this.訂購單infoTableAdapter.Fill(this.iii02_01DataSet.訂購單info);
                        訂購單infoBindingSource.MoveLast();
                        訂購單細項infoBindingSource.Filter = "已刪除=0 and 訂購單編號=" + 訂購單編號infoListBox.Text;
                        this.訂購單細項infoTableAdapter.Fill(this.iii02_01DataSet.訂購單細項info);
                        訂購單細項infoBindingSource.MoveLast();
                        TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "新增訂購單細項" + 訂購單細項編號ListBox.SelectedValue + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                    }
                }
                else//未有同餐廳未提交訂單，先新增訂購單再新增訂購單細項
                {
                    {//新增訂購單
                        sqlcmd = "insert into 訂購單 (經辦) values(" + userid + ")";
                        SqlConnection con = new SqlConnection(iii02sc.ToString());
                        con.Open();
                        string strSQL = sqlcmd;
                        SqlCommand cmd = new SqlCommand(strSQL, con);
                        rows = cmd.ExecuteNonQuery();
                        con.Close();

                        訂購單BindingSource.Filter = "已刪除=0";
                        this.訂購單TableAdapter.Fill(this.iii02_01DataSet.訂購單);
                        訂購單BindingSource.MoveLast();
                        TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "新增訂購單" + 訂購單編號ListBox.SelectedValue + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                    }
                    {//新增訂購單細項加入至最新訂購單編號(訂購單編號ListBox.SelectedValue)
                        sqlcmd = "insert into 訂購單細項 (訂購單編號,訂購人,品名編號,訂購數量) values(" + 訂購單編號ListBox.SelectedValue + "," + LB_userlist.SelectedValue + "," + LB_menulist.SelectedValue + "," + Convert.ToInt32(TB_ordercount.Text) + ")";
                        SqlConnection con = new SqlConnection(iii02sc.ToString());
                        con.Open();
                        string strSQL = sqlcmd;
                        SqlCommand cmd = new SqlCommand(strSQL, con);
                        rows = cmd.ExecuteNonQuery();
                        strSQL = "update 訂購單細項 set 訂購單細項.單價=菜單.單價 from 訂購單細項 inner join 菜單 on 訂購單細項.品名編號=菜單.品名編號 where 訂購單細項.單價=0";
                        SqlCommand cmd2 = new SqlCommand(strSQL, con);
                        cmd2.ExecuteNonQuery();
                        con.Close();
                        訂購單BindingSource.Filter = "已刪除=0";
                        this.訂購單TableAdapter.Fill(this.iii02_01DataSet.訂購單);
                        訂購單BindingSource.MoveLast();
                        訂購單infoBindingSource.Filter = "已刪除=0";
                        this.訂購單infoTableAdapter.Fill(this.iii02_01DataSet.訂購單info);
                        訂購單infoBindingSource.MoveLast();
                        訂購單細項infoBindingSource.Filter = "已刪除=0 and 訂購單編號=" + 訂購單編號infoListBox.Text;
                        this.訂購單細項infoTableAdapter.Fill(this.iii02_01DataSet.訂購單細項info);
                        訂購單細項infoBindingSource.MoveLast();
                        TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "新增訂購單細項" + 訂購單細項編號ListBox.SelectedValue + "資料完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                    }
                }

            }
        }

        private void 訂購單編號infoListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (訂購單編號infoListBox.SelectedValue != null)
            {
                訂購單細項infoBindingSource.Filter = "已刪除=0 and 訂購單編號=" + 訂購單編號infoListBox.Text;
                this.訂購單細項infoTableAdapter.Fill(this.iii02_01DataSet.訂購單細項info);
            }
            if (細項付款確認CheckBox.Checked)
            {
                細項付款確認Label.Text = "已收款";
            }
            else
            {
                細項付款確認Label.Text = "未收款";
            }

        }

        private void button_orderclose_Click(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(訂購單編號infoListBox.SelectedValue))
            {
                orderindex = this.訂購單infoBindingSource.Position;
                sqlcmd = "Update 訂購單 set 訂購提交=1,訂購狀態='已訂購' where 訂購單編號 = " + 訂購單編號infoListBox.Text;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "提交訂購單" + 訂購單編號infoListBox.Text +"完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                strSQL = "Update 訂購單細項 set 已刪除=1 where 細項付款確認=0 and 訂購單編號 = " + 訂購單編號infoListBox.Text;
                SqlCommand cmd2 = new SqlCommand(strSQL, con);
                rows = cmd2.ExecuteNonQuery();
                if (rows>0)
                {
                    TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "刪除"+ 訂購單編號infoListBox.Text + "訂購單之未付款細項" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                }
                con.Close();
                訂購單infoBindingSource.Filter = "已刪除=0";
                this.訂購單infoTableAdapter.Fill(this.iii02_01DataSet.訂購單info);
                this.訂購單infoBindingSource.Position = orderindex;
            }
            else
            {
                MessageBox.Show(string.Format("訂購單") + 訂購單編號infoListBox.Text + "已訂購 不可再次提交!");
            }
        }

        private void button_orderdel_Click(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(訂購單編號infoListBox.SelectedValue))
            {
                sqlcmd = "Update 訂購單 set 已刪除=1 where 訂購單編號 = " + 訂購單編號infoListBox.Text;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "刪除訂購單" + 訂購單編號infoListBox.Text + "完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                訂購單infoBindingSource.Filter = "已刪除=0";
                this.訂購單infoTableAdapter.Fill(this.iii02_01DataSet.訂購單info);
            }
            else
            {
                MessageBox.Show(string.Format("訂購單") + 訂購單編號infoListBox.Text +"已訂購 不可刪除!");
            }
        }

        private void button_subdel_Click(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(訂購單編號infoListBox.SelectedValue))
            {
                if (訂購單細項編號ListBox.SelectedValue.ToString() != "")
                {
                    sqlcmd = "Update 訂購單細項 set 已刪除=1 where 訂購單細項編號 = " + 訂購單細項編號ListBox.SelectedValue;
                    SqlConnection con = new SqlConnection(iii02sc.ToString());
                    con.Open();
                    string strSQL = sqlcmd;
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    rows = cmd.ExecuteNonQuery();
                    TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "刪除訂購單細項" + 訂購單細項編號ListBox.SelectedValue + "完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                    con.Close();
                    訂購單細項infoBindingSource.Filter = "已刪除=0";
                    this.訂購單細項infoTableAdapter.Fill(this.iii02_01DataSet.訂購單細項info);
                }
            }
            else
            {
                MessageBox.Show(string.Format("訂購單") + 訂購單編號infoListBox.Text + "已訂購 不可刪除!");
            }

        }

        private void button_subpaycheck_Click(object sender, EventArgs e)
        {
            if (訂購單細項編號ListBox.SelectedValue.ToString() != "")
            {
                sqlcmd = "Update 訂購單細項 set 細項付款確認=1 where 訂購單細項編號 = " + 訂購單細項編號ListBox.SelectedValue;
                SqlConnection con = new SqlConnection(iii02sc.ToString());
                con.Open();
                string strSQL = sqlcmd;
                SqlCommand cmd = new SqlCommand(strSQL, con);
                rows = cmd.ExecuteNonQuery();
                TB_uselog.AppendText(System.DateTime.Now + ":" + userid + " " + userneme + "訂購單細項" + 訂購單細項編號ListBox.SelectedValue + "細項付款確認完成" + string.Format(", 共影響{0}筆", rows) + Environment.NewLine);
                con.Close();
                訂購單細項infoBindingSource.Filter = "已刪除=0";
                this.訂購單細項infoTableAdapter.Fill(this.iii02_01DataSet.訂購單細項info);
                訂購單infoBindingSource.Filter = "已刪除=0";
                this.訂購單infoTableAdapter.Fill(this.iii02_01DataSet.訂購單info);
            }
        }



        private void 訂購單細項編號ListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (細項付款確認CheckBox.Checked)
            {
                細項付款確認Label.Text = "已收款";
            }
            else
            {
                細項付款確認Label.Text = "未收款";
            }
        }

        private void button_notpay_Click(object sender, EventArgs e)
        {
            if (訂購單編號infoListBox.SelectedValue != null)
            {
                訂購單細項infoBindingSource.Filter = "已刪除=0 and  細項付款確認=0 and 訂購單編號=" + 訂購單編號infoListBox.Text;
                this.訂購單細項infoTableAdapter.Fill(this.iii02_01DataSet.訂購單細項info);
            }
            if (細項付款確認CheckBox.Checked)
            {
                細項付款確認Label.Text = "已收款";
            }
            else
            {
                細項付款確認Label.Text = "未收款";
            }
        }

        private void LB_menushotlist_Click(object sender, EventArgs e)
        {
            if (LB_menushotlist.SelectedValue != null)
            {
                菜單infoBindingSource.Filter = "已刪除=0 and  店家編號=" + LB_menushotlist.SelectedValue;
                this.菜單infoBindingSource.MoveLast();
                訂購單infoBindingSource2.Filter = "已刪除=0 and 訂購提交=0 and  店家編號=" + LB_menushotlist.SelectedValue;
            }
        }

        private void LB_menushotlist_DoubleClick(object sender, EventArgs e)
        {
 
            if (LB_menushotlist.SelectedValue != null)
            {
                店名Label3.Text = LB_menushotlist.Text;
            }
        }

    }
}
