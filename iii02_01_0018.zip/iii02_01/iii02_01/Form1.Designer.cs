﻿namespace iii02_01
{
    partial class TB_userlistSC
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label 小計Label;
            System.Windows.Forms.Label 細項付款確認Label1;
            System.Windows.Forms.Label 訂購時間Label2;
            System.Windows.Forms.Label 單價Label3;
            System.Windows.Forms.Label 訂購數量Label1;
            System.Windows.Forms.Label 品名Label1;
            System.Windows.Forms.Label 姓名Label;
            System.Windows.Forms.Label 訂購單細項編號Label1;
            System.Windows.Forms.Label 地址Label1;
            System.Windows.Forms.Label 電話Label1;
            System.Windows.Forms.Label 店名Label1;
            System.Windows.Forms.Label 訂購人數Label;
            System.Windows.Forms.Label 訂購品項數量Label;
            System.Windows.Forms.Label 訂購總金額Label;
            System.Windows.Forms.Label 訂購總數量Label;
            System.Windows.Forms.Label 訂購狀態Label;
            System.Windows.Forms.Label 訂購日期Label;
            System.Windows.Forms.Label 經辦姓名Label;
            System.Windows.Forms.Label 訂購單編號Label;
            System.Windows.Forms.Label 未付款金額Label;
            System.Windows.Forms.Label 備註Label1;
            System.Windows.Forms.Label 供應限制Label;
            System.Windows.Forms.Label 店家編號Label1;
            System.Windows.Forms.Label 單價Label;
            System.Windows.Forms.Label 品名Label;
            System.Windows.Forms.Label 品名編號Label;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label 備註Label;
            System.Windows.Forms.Label 地址Label;
            System.Windows.Forms.Label 電話Label;
            System.Windows.Forms.Label 店名Label;
            System.Windows.Forms.Label 店家編號Label;
            System.Windows.Forms.Label LAB_shopid;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label LAB_userid;
            System.Windows.Forms.Label label15;
            this.菜單infoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iii02_01DataSet = new iii02_01.iii02_01DataSet();
            this.店家BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.訂購人BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bt_login = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LB_user = new System.Windows.Forms.ListBox();
            this.訂購單細項infoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.訂購單infoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.訂購單BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.訂購單infoBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tableAdapterManager = new iii02_01.iii02_01DataSetTableAdapters.TableAdapterManager();
            this.訂購人TableAdapter = new iii02_01.iii02_01DataSetTableAdapters.訂購人TableAdapter();
            this.店家TableAdapter = new iii02_01.iii02_01DataSetTableAdapters.店家TableAdapter();
            this.TB_userSC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.菜單infoTableAdapter = new iii02_01.iii02_01DataSetTableAdapters.菜單infoTableAdapter();
            this.餐廳BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.餐廳TableAdapter = new iii02_01.iii02_01DataSetTableAdapters.餐廳TableAdapter();
            this.TB_uselog = new System.Windows.Forms.TextBox();
            this.訂購單TableAdapter = new iii02_01.iii02_01DataSetTableAdapters.訂購單TableAdapter();
            this.訂購單細項infoTableAdapter = new iii02_01.iii02_01DataSetTableAdapters.訂購單細項infoTableAdapter();
            this.訂購單infoTableAdapter = new iii02_01.iii02_01DataSetTableAdapters.訂購單infoTableAdapter();
            this.訂購單infoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage_orders = new System.Windows.Forms.TabPage();
            this.訂購數量Label2 = new System.Windows.Forms.Label();
            this.單價Label2 = new System.Windows.Forms.Label();
            this.button_notpay = new System.Windows.Forms.Button();
            this.細項付款確認Label = new System.Windows.Forms.Label();
            this.button_subdel = new System.Windows.Forms.Button();
            this.button_subpaycheck = new System.Windows.Forms.Button();
            this.button_orderdel = new System.Windows.Forms.Button();
            this.button_orderclose = new System.Windows.Forms.Button();
            this.訂購單編號infoListBox = new System.Windows.Forms.ListBox();
            this.經辦姓名Label1 = new System.Windows.Forms.Label();
            this.訂購日期Label1 = new System.Windows.Forms.Label();
            this.訂購狀態Label1 = new System.Windows.Forms.Label();
            this.訂購總數量Label1 = new System.Windows.Forms.Label();
            this.訂購總金額Label1 = new System.Windows.Forms.Label();
            this.訂購品項數量Label1 = new System.Windows.Forms.Label();
            this.訂購人數Label1 = new System.Windows.Forms.Label();
            this.店名Label2 = new System.Windows.Forms.Label();
            this.電話Label2 = new System.Windows.Forms.Label();
            this.地址Label2 = new System.Windows.Forms.Label();
            this.訂購單細項編號ListBox = new System.Windows.Forms.ListBox();
            this.姓名Label1 = new System.Windows.Forms.Label();
            this.品名Label2 = new System.Windows.Forms.Label();
            this.訂購時間Label3 = new System.Windows.Forms.Label();
            this.小計Label1 = new System.Windows.Forms.Label();
            this.細項付款確認CheckBox = new System.Windows.Forms.CheckBox();
            this.tabPage_menu = new System.Windows.Forms.TabPage();
            this.button_orderadd = new System.Windows.Forms.Button();
            this.TB_ordercount = new System.Windows.Forms.TextBox();
            this.菜色圖片TextBox = new System.Windows.Forms.TextBox();
            this.TB_menuCS = new System.Windows.Forms.TextBox();
            this.品名TextBox = new System.Windows.Forms.TextBox();
            this.單價TextBox = new System.Windows.Forms.TextBox();
            this.供應限制TextBox = new System.Windows.Forms.TextBox();
            this.備註TextBox1 = new System.Windows.Forms.TextBox();
            this.LB_menushotlist = new System.Windows.Forms.ListBox();
            this.菜色圖片Label = new System.Windows.Forms.Label();
            this.PIC_menu = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button_menucls = new System.Windows.Forms.Button();
            this.button_menudle = new System.Windows.Forms.Button();
            this.button_menuupdata = new System.Windows.Forms.Button();
            this.button_menuins = new System.Windows.Forms.Button();
            this.LB_menulist = new System.Windows.Forms.ListBox();
            this.店名Label3 = new System.Windows.Forms.Label();
            this.LB_訂購單未提交 = new System.Windows.Forms.ListBox();
            this.訂購單編號ListBox = new System.Windows.Forms.ListBox();
            this.tabPage_shop = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.TB_shopSC = new System.Windows.Forms.TextBox();
            this.店名TextBox = new System.Windows.Forms.TextBox();
            this.電話TextBox = new System.Windows.Forms.TextBox();
            this.地址TextBox = new System.Windows.Forms.TextBox();
            this.備註TextBox = new System.Windows.Forms.TextBox();
            this.TB_shopTBcls = new System.Windows.Forms.Button();
            this.button_shopdel = new System.Windows.Forms.Button();
            this.button_shopupdata = new System.Windows.Forms.Button();
            this.button_shopins = new System.Windows.Forms.Button();
            this.LB_shoplist = new System.Windows.Forms.ListBox();
            this.tabPage_member = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.TB_userSC2 = new System.Windows.Forms.TextBox();
            this.TB_userremark = new System.Windows.Forms.TextBox();
            this.TB_userclassroom = new System.Windows.Forms.TextBox();
            this.TB_useridentity = new System.Windows.Forms.TextBox();
            this.TB_usertel = new System.Windows.Forms.TextBox();
            this.TB_username = new System.Windows.Forms.TextBox();
            this.TB_userTBcls = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LB_userid = new System.Windows.Forms.Label();
            this.button_useridel = new System.Windows.Forms.Button();
            this.button_userupdata = new System.Windows.Forms.Button();
            this.button_userins = new System.Windows.Forms.Button();
            this.LB_userlist = new System.Windows.Forms.ListBox();
            this.tabControl_iii = new System.Windows.Forms.TabControl();
            小計Label = new System.Windows.Forms.Label();
            細項付款確認Label1 = new System.Windows.Forms.Label();
            訂購時間Label2 = new System.Windows.Forms.Label();
            單價Label3 = new System.Windows.Forms.Label();
            訂購數量Label1 = new System.Windows.Forms.Label();
            品名Label1 = new System.Windows.Forms.Label();
            姓名Label = new System.Windows.Forms.Label();
            訂購單細項編號Label1 = new System.Windows.Forms.Label();
            地址Label1 = new System.Windows.Forms.Label();
            電話Label1 = new System.Windows.Forms.Label();
            店名Label1 = new System.Windows.Forms.Label();
            訂購人數Label = new System.Windows.Forms.Label();
            訂購品項數量Label = new System.Windows.Forms.Label();
            訂購總金額Label = new System.Windows.Forms.Label();
            訂購總數量Label = new System.Windows.Forms.Label();
            訂購狀態Label = new System.Windows.Forms.Label();
            訂購日期Label = new System.Windows.Forms.Label();
            經辦姓名Label = new System.Windows.Forms.Label();
            訂購單編號Label = new System.Windows.Forms.Label();
            未付款金額Label = new System.Windows.Forms.Label();
            備註Label1 = new System.Windows.Forms.Label();
            供應限制Label = new System.Windows.Forms.Label();
            店家編號Label1 = new System.Windows.Forms.Label();
            單價Label = new System.Windows.Forms.Label();
            品名Label = new System.Windows.Forms.Label();
            品名編號Label = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            備註Label = new System.Windows.Forms.Label();
            地址Label = new System.Windows.Forms.Label();
            電話Label = new System.Windows.Forms.Label();
            店名Label = new System.Windows.Forms.Label();
            店家編號Label = new System.Windows.Forms.Label();
            LAB_shopid = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            LAB_userid = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.菜單infoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iii02_01DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.店家BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購人BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單細項infoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單infoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單infoBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.餐廳BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單infoBindingSource1)).BeginInit();
            this.tabPage_orders.SuspendLayout();
            this.tabPage_menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PIC_menu)).BeginInit();
            this.tabPage_shop.SuspendLayout();
            this.tabPage_member.SuspendLayout();
            this.tabControl_iii.SuspendLayout();
            this.SuspendLayout();
            // 
            // 小計Label
            // 
            小計Label.AutoSize = true;
            小計Label.Location = new System.Drawing.Point(749, 350);
            小計Label.Name = "小計Label";
            小計Label.Size = new System.Drawing.Size(45, 20);
            小計Label.TabIndex = 69;
            小計Label.Text = "小計:";
            // 
            // 細項付款確認Label1
            // 
            細項付款確認Label1.AutoSize = true;
            細項付款確認Label1.Location = new System.Drawing.Point(749, 300);
            細項付款確認Label1.Name = "細項付款確認Label1";
            細項付款確認Label1.Size = new System.Drawing.Size(109, 20);
            細項付款確認Label1.TabIndex = 65;
            細項付款確認Label1.Text = "細項付款確認:";
            // 
            // 訂購時間Label2
            // 
            訂購時間Label2.AutoSize = true;
            訂購時間Label2.Location = new System.Drawing.Point(749, 250);
            訂購時間Label2.Name = "訂購時間Label2";
            訂購時間Label2.Size = new System.Drawing.Size(77, 20);
            訂購時間Label2.TabIndex = 63;
            訂購時間Label2.Text = "訂購時間:";
            // 
            // 單價Label3
            // 
            單價Label3.AutoSize = true;
            單價Label3.Location = new System.Drawing.Point(749, 200);
            單價Label3.Name = "單價Label3";
            單價Label3.Size = new System.Drawing.Size(45, 20);
            單價Label3.TabIndex = 53;
            單價Label3.Text = "單價:";
            // 
            // 訂購數量Label1
            // 
            訂購數量Label1.AutoSize = true;
            訂購數量Label1.Location = new System.Drawing.Point(749, 150);
            訂購數量Label1.Name = "訂購數量Label1";
            訂購數量Label1.Size = new System.Drawing.Size(77, 20);
            訂購數量Label1.TabIndex = 51;
            訂購數量Label1.Text = "訂購數量:";
            // 
            // 品名Label1
            // 
            品名Label1.AutoSize = true;
            品名Label1.Location = new System.Drawing.Point(749, 100);
            品名Label1.Name = "品名Label1";
            品名Label1.Size = new System.Drawing.Size(45, 20);
            品名Label1.TabIndex = 49;
            品名Label1.Text = "品名:";
            // 
            // 姓名Label
            // 
            姓名Label.AutoSize = true;
            姓名Label.Location = new System.Drawing.Point(749, 50);
            姓名Label.Name = "姓名Label";
            姓名Label.Size = new System.Drawing.Size(45, 20);
            姓名Label.TabIndex = 45;
            姓名Label.Text = "姓名:";
            // 
            // 訂購單細項編號Label1
            // 
            訂購單細項編號Label1.AutoSize = true;
            訂購單細項編號Label1.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            訂購單細項編號Label1.Location = new System.Drawing.Point(715, 6);
            訂購單細項編號Label1.Name = "訂購單細項編號Label1";
            訂購單細項編號Label1.Size = new System.Drawing.Size(152, 27);
            訂購單細項編號Label1.TabIndex = 39;
            訂購單細項編號Label1.Text = "訂購單細項";
            // 
            // 地址Label1
            // 
            地址Label1.AutoSize = true;
            地址Label1.Location = new System.Drawing.Point(40, 350);
            地址Label1.Name = "地址Label1";
            地址Label1.Size = new System.Drawing.Size(45, 20);
            地址Label1.TabIndex = 96;
            地址Label1.Text = "地址:";
            // 
            // 電話Label1
            // 
            電話Label1.AutoSize = true;
            電話Label1.Location = new System.Drawing.Point(40, 300);
            電話Label1.Name = "電話Label1";
            電話Label1.Size = new System.Drawing.Size(45, 20);
            電話Label1.TabIndex = 94;
            電話Label1.Text = "電話:";
            // 
            // 店名Label1
            // 
            店名Label1.AutoSize = true;
            店名Label1.Location = new System.Drawing.Point(40, 250);
            店名Label1.Name = "店名Label1";
            店名Label1.Size = new System.Drawing.Size(45, 20);
            店名Label1.TabIndex = 92;
            店名Label1.Text = "店名:";
            // 
            // 訂購人數Label
            // 
            訂購人數Label.AutoSize = true;
            訂購人數Label.Location = new System.Drawing.Point(40, 200);
            訂購人數Label.Name = "訂購人數Label";
            訂購人數Label.Size = new System.Drawing.Size(77, 20);
            訂購人數Label.TabIndex = 88;
            訂購人數Label.Text = "訂購人數:";
            // 
            // 訂購品項數量Label
            // 
            訂購品項數量Label.AutoSize = true;
            訂購品項數量Label.Location = new System.Drawing.Point(271, 150);
            訂購品項數量Label.Name = "訂購品項數量Label";
            訂購品項數量Label.Size = new System.Drawing.Size(109, 20);
            訂購品項數量Label.TabIndex = 86;
            訂購品項數量Label.Text = "訂購品項數量:";
            // 
            // 訂購總金額Label
            // 
            訂購總金額Label.AutoSize = true;
            訂購總金額Label.Location = new System.Drawing.Point(271, 100);
            訂購總金額Label.Name = "訂購總金額Label";
            訂購總金額Label.Size = new System.Drawing.Size(93, 20);
            訂購總金額Label.TabIndex = 84;
            訂購總金額Label.Text = "訂購總金額:";
            // 
            // 訂購總數量Label
            // 
            訂購總數量Label.AutoSize = true;
            訂購總數量Label.Location = new System.Drawing.Point(271, 50);
            訂購總數量Label.Name = "訂購總數量Label";
            訂購總數量Label.Size = new System.Drawing.Size(93, 20);
            訂購總數量Label.TabIndex = 82;
            訂購總數量Label.Text = "訂購總數量:";
            // 
            // 訂購狀態Label
            // 
            訂購狀態Label.AutoSize = true;
            訂購狀態Label.Location = new System.Drawing.Point(40, 150);
            訂購狀態Label.Name = "訂購狀態Label";
            訂購狀態Label.Size = new System.Drawing.Size(77, 20);
            訂購狀態Label.TabIndex = 76;
            訂購狀態Label.Text = "訂購狀態:";
            // 
            // 訂購日期Label
            // 
            訂購日期Label.AutoSize = true;
            訂購日期Label.Location = new System.Drawing.Point(40, 100);
            訂購日期Label.Name = "訂購日期Label";
            訂購日期Label.Size = new System.Drawing.Size(77, 20);
            訂購日期Label.TabIndex = 74;
            訂購日期Label.Text = "訂購日期:";
            // 
            // 經辦姓名Label
            // 
            經辦姓名Label.AutoSize = true;
            經辦姓名Label.Location = new System.Drawing.Point(40, 50);
            經辦姓名Label.Name = "經辦姓名Label";
            經辦姓名Label.Size = new System.Drawing.Size(61, 20);
            經辦姓名Label.TabIndex = 72;
            經辦姓名Label.Text = "值日生:";
            // 
            // 訂購單編號Label
            // 
            訂購單編號Label.AutoSize = true;
            訂購單編號Label.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            訂購單編號Label.Location = new System.Drawing.Point(6, 6);
            訂購單編號Label.Name = "訂購單編號Label";
            訂購單編號Label.Size = new System.Drawing.Size(96, 27);
            訂購單編號Label.TabIndex = 70;
            訂購單編號Label.Text = "訂購單";
            // 
            // 未付款金額Label
            // 
            未付款金額Label.AutoSize = true;
            未付款金額Label.Location = new System.Drawing.Point(271, 200);
            未付款金額Label.Name = "未付款金額Label";
            未付款金額Label.Size = new System.Drawing.Size(93, 20);
            未付款金額Label.TabIndex = 103;
            未付款金額Label.Text = "未付款金額:";
            // 
            // 備註Label1
            // 
            備註Label1.AutoSize = true;
            備註Label1.Location = new System.Drawing.Point(40, 300);
            備註Label1.Name = "備註Label1";
            備註Label1.Size = new System.Drawing.Size(45, 20);
            備註Label1.TabIndex = 14;
            備註Label1.Text = "備註:";
            // 
            // 供應限制Label
            // 
            供應限制Label.AutoSize = true;
            供應限制Label.Location = new System.Drawing.Point(40, 250);
            供應限制Label.Name = "供應限制Label";
            供應限制Label.Size = new System.Drawing.Size(77, 20);
            供應限制Label.TabIndex = 8;
            供應限制Label.Text = "供應限制:";
            // 
            // 店家編號Label1
            // 
            店家編號Label1.AutoSize = true;
            店家編號Label1.Location = new System.Drawing.Point(40, 200);
            店家編號Label1.Name = "店家編號Label1";
            店家編號Label1.Size = new System.Drawing.Size(45, 20);
            店家編號Label1.TabIndex = 6;
            店家編號Label1.Text = "店家:";
            // 
            // 單價Label
            // 
            單價Label.AutoSize = true;
            單價Label.Location = new System.Drawing.Point(40, 150);
            單價Label.Name = "單價Label";
            單價Label.Size = new System.Drawing.Size(45, 20);
            單價Label.TabIndex = 4;
            單價Label.Text = "單價:";
            // 
            // 品名Label
            // 
            品名Label.AutoSize = true;
            品名Label.Location = new System.Drawing.Point(40, 100);
            品名Label.Name = "品名Label";
            品名Label.Size = new System.Drawing.Size(45, 20);
            品名Label.TabIndex = 2;
            品名Label.Text = "品名:";
            // 
            // 品名編號Label
            // 
            品名編號Label.AutoSize = true;
            品名編號Label.Location = new System.Drawing.Point(40, 50);
            品名編號Label.Name = "品名編號Label";
            品名編號Label.Size = new System.Drawing.Size(77, 20);
            品名編號Label.TabIndex = 0;
            品名編號Label.Text = "品名編號:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "品名編號", true));
            label10.Location = new System.Drawing.Point(130, 50);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(30, 20);
            label10.TabIndex = 34;
            label10.Text = "ID:";
            // 
            // 菜單infoBindingSource
            // 
            this.菜單infoBindingSource.DataMember = "菜單info";
            this.菜單infoBindingSource.DataSource = this.iii02_01DataSet;
            // 
            // iii02_01DataSet
            // 
            this.iii02_01DataSet.DataSetName = "iii02_01DataSet";
            this.iii02_01DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(1040, 362);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(73, 20);
            label13.TabIndex = 59;
            label13.Text = "訂購數量";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            label12.Location = new System.Drawing.Point(6, 6);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(68, 27);
            label12.TabIndex = 101;
            label12.Text = "菜單";
            // 
            // 備註Label
            // 
            備註Label.AutoSize = true;
            備註Label.Location = new System.Drawing.Point(40, 250);
            備註Label.Name = "備註Label";
            備註Label.Size = new System.Drawing.Size(45, 20);
            備註Label.TabIndex = 10;
            備註Label.Text = "備註:";
            // 
            // 地址Label
            // 
            地址Label.AutoSize = true;
            地址Label.Location = new System.Drawing.Point(40, 200);
            地址Label.Name = "地址Label";
            地址Label.Size = new System.Drawing.Size(45, 20);
            地址Label.TabIndex = 6;
            地址Label.Text = "地址:";
            // 
            // 電話Label
            // 
            電話Label.AutoSize = true;
            電話Label.Location = new System.Drawing.Point(40, 150);
            電話Label.Name = "電話Label";
            電話Label.Size = new System.Drawing.Size(45, 20);
            電話Label.TabIndex = 4;
            電話Label.Text = "電話:";
            // 
            // 店名Label
            // 
            店名Label.AutoSize = true;
            店名Label.Location = new System.Drawing.Point(40, 100);
            店名Label.Name = "店名Label";
            店名Label.Size = new System.Drawing.Size(45, 20);
            店名Label.TabIndex = 2;
            店名Label.Text = "店名:";
            // 
            // 店家編號Label
            // 
            店家編號Label.AutoSize = true;
            店家編號Label.Location = new System.Drawing.Point(40, 50);
            店家編號Label.Name = "店家編號Label";
            店家編號Label.Size = new System.Drawing.Size(77, 20);
            店家編號Label.TabIndex = 0;
            店家編號Label.Text = "店家編號:";
            // 
            // LAB_shopid
            // 
            LAB_shopid.AutoSize = true;
            LAB_shopid.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.店家BindingSource, "店家編號", true));
            LAB_shopid.Location = new System.Drawing.Point(130, 50);
            LAB_shopid.Name = "LAB_shopid";
            LAB_shopid.Size = new System.Drawing.Size(30, 20);
            LAB_shopid.TabIndex = 33;
            LAB_shopid.Text = "ID:";
            // 
            // 店家BindingSource
            // 
            this.店家BindingSource.DataMember = "店家";
            this.店家BindingSource.DataSource = this.iii02_01DataSet;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            label14.Location = new System.Drawing.Point(6, 6);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(68, 27);
            label14.TabIndex = 71;
            label14.Text = "餐廳";
            // 
            // LAB_userid
            // 
            LAB_userid.AutoSize = true;
            LAB_userid.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購人BindingSource, "訂購人編號", true));
            LAB_userid.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            LAB_userid.Location = new System.Drawing.Point(130, 50);
            LAB_userid.Name = "LAB_userid";
            LAB_userid.Size = new System.Drawing.Size(30, 20);
            LAB_userid.TabIndex = 32;
            LAB_userid.Text = "ID:";
            // 
            // 訂購人BindingSource
            // 
            this.訂購人BindingSource.DataMember = "訂購人";
            this.訂購人BindingSource.DataSource = this.iii02_01DataSet;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            label15.Location = new System.Drawing.Point(6, 6);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(68, 27);
            label15.TabIndex = 71;
            label15.Text = "成員";
            // 
            // bt_login
            // 
            this.bt_login.BackColor = System.Drawing.Color.Yellow;
            this.bt_login.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bt_login.ForeColor = System.Drawing.Color.Maroon;
            this.bt_login.Location = new System.Drawing.Point(1325, 2);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(75, 31);
            this.bt_login.TabIndex = 1;
            this.bt_login.Text = "登入";
            this.bt_login.UseVisualStyleBackColor = false;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(8, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "請雙擊姓名後登入";
            // 
            // LB_user
            // 
            this.LB_user.BackColor = System.Drawing.Color.Black;
            this.LB_user.DataSource = this.訂購人BindingSource;
            this.LB_user.DisplayMember = "姓名";
            this.LB_user.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LB_user.ForeColor = System.Drawing.Color.Lime;
            this.LB_user.FormattingEnabled = true;
            this.LB_user.ItemHeight = 21;
            this.LB_user.Location = new System.Drawing.Point(2, 33);
            this.LB_user.Name = "LB_user";
            this.LB_user.Size = new System.Drawing.Size(200, 655);
            this.LB_user.TabIndex = 7;
            this.LB_user.ValueMember = "訂購人編號";
            this.LB_user.DoubleClick += new System.EventHandler(this.bt_login_Click);
            // 
            // 訂購單細項infoBindingSource
            // 
            this.訂購單細項infoBindingSource.DataMember = "訂購單細項info";
            this.訂購單細項infoBindingSource.DataSource = this.iii02_01DataSet;
            // 
            // 訂購單infoBindingSource
            // 
            this.訂購單infoBindingSource.DataMember = "訂購單info";
            this.訂購單infoBindingSource.DataSource = this.iii02_01DataSet;
            // 
            // 訂購單BindingSource
            // 
            this.訂購單BindingSource.DataMember = "訂購單";
            this.訂購單BindingSource.DataSource = this.iii02_01DataSet;
            // 
            // 訂購單infoBindingSource2
            // 
            this.訂購單infoBindingSource2.DataMember = "訂購單info";
            this.訂購單infoBindingSource2.DataSource = this.iii02_01DataSet;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.UpdateOrder = iii02_01.iii02_01DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.取貨單TableAdapter = null;
            this.tableAdapterManager.取貨單細項TableAdapter = null;
            this.tableAdapterManager.店家TableAdapter = null;
            this.tableAdapterManager.店家其他資訊TableAdapter = null;
            this.tableAdapterManager.店家評價TableAdapter = null;
            this.tableAdapterManager.收貨單TableAdapter = null;
            this.tableAdapterManager.收貨單細項TableAdapter = null;
            this.tableAdapterManager.菜單TableAdapter = null;
            this.tableAdapterManager.菜單評價TableAdapter = null;
            this.tableAdapterManager.訂購人TableAdapter = null;
            this.tableAdapterManager.訂購人其他資訊TableAdapter = null;
            this.tableAdapterManager.訂購單TableAdapter = null;
            this.tableAdapterManager.訂購單細項TableAdapter = null;
            this.tableAdapterManager.評價單TableAdapter = null;
            this.tableAdapterManager.退訂單TableAdapter = null;
            this.tableAdapterManager.退訂單細項TableAdapter = null;
            // 
            // 訂購人TableAdapter
            // 
            this.訂購人TableAdapter.ClearBeforeFill = true;
            // 
            // 店家TableAdapter
            // 
            this.店家TableAdapter.ClearBeforeFill = true;
            // 
            // TB_userSC
            // 
            this.TB_userSC.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_userSC.Location = new System.Drawing.Point(292, 1);
            this.TB_userSC.Name = "TB_userSC";
            this.TB_userSC.Size = new System.Drawing.Size(373, 29);
            this.TB_userSC.TabIndex = 27;
            this.TB_userSC.TextChanged += new System.EventHandler(this.TB_userSC_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(207, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 21);
            this.label2.TabIndex = 28;
            this.label2.Text = "搜尋姓名:";
            // 
            // 菜單infoTableAdapter
            // 
            this.菜單infoTableAdapter.ClearBeforeFill = true;
            // 
            // 餐廳BindingSource
            // 
            this.餐廳BindingSource.DataMember = "餐廳";
            this.餐廳BindingSource.DataSource = this.iii02_01DataSet;
            // 
            // 餐廳TableAdapter
            // 
            this.餐廳TableAdapter.ClearBeforeFill = true;
            // 
            // TB_uselog
            // 
            this.TB_uselog.BackColor = System.Drawing.Color.Black;
            this.TB_uselog.ForeColor = System.Drawing.Color.Lime;
            this.TB_uselog.Location = new System.Drawing.Point(208, 549);
            this.TB_uselog.Multiline = true;
            this.TB_uselog.Name = "TB_uselog";
            this.TB_uselog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TB_uselog.Size = new System.Drawing.Size(1192, 139);
            this.TB_uselog.TabIndex = 29;
            // 
            // 訂購單TableAdapter
            // 
            this.訂購單TableAdapter.ClearBeforeFill = true;
            // 
            // 訂購單細項infoTableAdapter
            // 
            this.訂購單細項infoTableAdapter.ClearBeforeFill = true;
            // 
            // 訂購單infoTableAdapter
            // 
            this.訂購單infoTableAdapter.ClearBeforeFill = true;
            // 
            // 訂購單infoBindingSource1
            // 
            this.訂購單infoBindingSource1.DataMember = "訂購單info";
            this.訂購單infoBindingSource1.DataSource = this.iii02_01DataSet;
            // 
            // tabPage_orders
            // 
            this.tabPage_orders.AutoScroll = true;
            this.tabPage_orders.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage_orders.Controls.Add(this.訂購數量Label2);
            this.tabPage_orders.Controls.Add(this.單價Label2);
            this.tabPage_orders.Controls.Add(this.button_notpay);
            this.tabPage_orders.Controls.Add(未付款金額Label);
            this.tabPage_orders.Controls.Add(this.細項付款確認Label);
            this.tabPage_orders.Controls.Add(this.button_subdel);
            this.tabPage_orders.Controls.Add(this.button_subpaycheck);
            this.tabPage_orders.Controls.Add(this.button_orderdel);
            this.tabPage_orders.Controls.Add(this.button_orderclose);
            this.tabPage_orders.Controls.Add(訂購單編號Label);
            this.tabPage_orders.Controls.Add(this.訂購單編號infoListBox);
            this.tabPage_orders.Controls.Add(經辦姓名Label);
            this.tabPage_orders.Controls.Add(this.經辦姓名Label1);
            this.tabPage_orders.Controls.Add(訂購日期Label);
            this.tabPage_orders.Controls.Add(this.訂購日期Label1);
            this.tabPage_orders.Controls.Add(訂購狀態Label);
            this.tabPage_orders.Controls.Add(this.訂購狀態Label1);
            this.tabPage_orders.Controls.Add(訂購總數量Label);
            this.tabPage_orders.Controls.Add(this.訂購總數量Label1);
            this.tabPage_orders.Controls.Add(訂購總金額Label);
            this.tabPage_orders.Controls.Add(this.訂購總金額Label1);
            this.tabPage_orders.Controls.Add(訂購品項數量Label);
            this.tabPage_orders.Controls.Add(this.訂購品項數量Label1);
            this.tabPage_orders.Controls.Add(訂購人數Label);
            this.tabPage_orders.Controls.Add(this.訂購人數Label1);
            this.tabPage_orders.Controls.Add(店名Label1);
            this.tabPage_orders.Controls.Add(this.店名Label2);
            this.tabPage_orders.Controls.Add(電話Label1);
            this.tabPage_orders.Controls.Add(this.電話Label2);
            this.tabPage_orders.Controls.Add(地址Label1);
            this.tabPage_orders.Controls.Add(this.地址Label2);
            this.tabPage_orders.Controls.Add(訂購單細項編號Label1);
            this.tabPage_orders.Controls.Add(this.訂購單細項編號ListBox);
            this.tabPage_orders.Controls.Add(姓名Label);
            this.tabPage_orders.Controls.Add(this.姓名Label1);
            this.tabPage_orders.Controls.Add(品名Label1);
            this.tabPage_orders.Controls.Add(this.品名Label2);
            this.tabPage_orders.Controls.Add(訂購數量Label1);
            this.tabPage_orders.Controls.Add(單價Label3);
            this.tabPage_orders.Controls.Add(訂購時間Label2);
            this.tabPage_orders.Controls.Add(this.訂購時間Label3);
            this.tabPage_orders.Controls.Add(細項付款確認Label1);
            this.tabPage_orders.Controls.Add(小計Label);
            this.tabPage_orders.Controls.Add(this.小計Label1);
            this.tabPage_orders.Controls.Add(this.細項付款確認CheckBox);
            this.tabPage_orders.Location = new System.Drawing.Point(4, 29);
            this.tabPage_orders.Name = "tabPage_orders";
            this.tabPage_orders.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_orders.Size = new System.Drawing.Size(1384, 494);
            this.tabPage_orders.TabIndex = 2;
            this.tabPage_orders.Text = "訂購管理";
            // 
            // 訂購數量Label2
            // 
            this.訂購數量Label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "訂購數量", true));
            this.訂購數量Label2.Location = new System.Drawing.Point(867, 150);
            this.訂購數量Label2.Name = "訂購數量Label2";
            this.訂購數量Label2.Size = new System.Drawing.Size(100, 23);
            this.訂購數量Label2.TabIndex = 107;
            this.訂購數量Label2.Text = "label14";
            // 
            // 單價Label2
            // 
            this.單價Label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "單價", true));
            this.單價Label2.Location = new System.Drawing.Point(867, 200);
            this.單價Label2.Name = "單價Label2";
            this.單價Label2.Size = new System.Drawing.Size(100, 23);
            this.單價Label2.TabIndex = 106;
            this.單價Label2.Text = "label14";
            // 
            // button_notpay
            // 
            this.button_notpay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button_notpay.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "未付款金額", true));
            this.button_notpay.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_notpay.ForeColor = System.Drawing.Color.Red;
            this.button_notpay.Location = new System.Drawing.Point(373, 188);
            this.button_notpay.Name = "button_notpay";
            this.button_notpay.Size = new System.Drawing.Size(130, 47);
            this.button_notpay.TabIndex = 105;
            this.button_notpay.Text = "未付款細項";
            this.button_notpay.UseVisualStyleBackColor = false;
            this.button_notpay.Click += new System.EventHandler(this.button_notpay_Click);
            // 
            // 細項付款確認Label
            // 
            this.細項付款確認Label.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "細項付款確認", true));
            this.細項付款確認Label.Location = new System.Drawing.Point(867, 300);
            this.細項付款確認Label.Name = "細項付款確認Label";
            this.細項付款確認Label.Size = new System.Drawing.Size(100, 23);
            this.細項付款確認Label.TabIndex = 102;
            // 
            // button_subdel
            // 
            this.button_subdel.BackColor = System.Drawing.Color.Red;
            this.button_subdel.ForeColor = System.Drawing.Color.Yellow;
            this.button_subdel.Location = new System.Drawing.Point(1042, 420);
            this.button_subdel.Name = "button_subdel";
            this.button_subdel.Size = new System.Drawing.Size(130, 50);
            this.button_subdel.TabIndex = 101;
            this.button_subdel.Text = "細項刪除";
            this.button_subdel.UseVisualStyleBackColor = false;
            this.button_subdel.Click += new System.EventHandler(this.button_subdel_Click);
            // 
            // button_subpaycheck
            // 
            this.button_subpaycheck.BackColor = System.Drawing.Color.Cyan;
            this.button_subpaycheck.ForeColor = System.Drawing.Color.Purple;
            this.button_subpaycheck.Location = new System.Drawing.Point(1042, 335);
            this.button_subpaycheck.Name = "button_subpaycheck";
            this.button_subpaycheck.Size = new System.Drawing.Size(130, 50);
            this.button_subpaycheck.TabIndex = 100;
            this.button_subpaycheck.Text = "付款確認";
            this.button_subpaycheck.UseVisualStyleBackColor = false;
            this.button_subpaycheck.Click += new System.EventHandler(this.button_subpaycheck_Click);
            // 
            // button_orderdel
            // 
            this.button_orderdel.BackColor = System.Drawing.Color.Red;
            this.button_orderdel.ForeColor = System.Drawing.Color.Yellow;
            this.button_orderdel.Location = new System.Drawing.Point(373, 420);
            this.button_orderdel.Name = "button_orderdel";
            this.button_orderdel.Size = new System.Drawing.Size(130, 50);
            this.button_orderdel.TabIndex = 99;
            this.button_orderdel.Text = "訂單刪除";
            this.button_orderdel.UseVisualStyleBackColor = false;
            this.button_orderdel.Click += new System.EventHandler(this.button_orderdel_Click);
            // 
            // button_orderclose
            // 
            this.button_orderclose.BackColor = System.Drawing.Color.Cyan;
            this.button_orderclose.ForeColor = System.Drawing.Color.Purple;
            this.button_orderclose.Location = new System.Drawing.Point(373, 335);
            this.button_orderclose.Name = "button_orderclose";
            this.button_orderclose.Size = new System.Drawing.Size(130, 50);
            this.button_orderclose.TabIndex = 98;
            this.button_orderclose.Text = "訂單提交";
            this.button_orderclose.UseVisualStyleBackColor = false;
            this.button_orderclose.Click += new System.EventHandler(this.button_orderclose_Click);
            // 
            // 訂購單編號infoListBox
            // 
            this.訂購單編號infoListBox.BackColor = System.Drawing.Color.Black;
            this.訂購單編號infoListBox.DataSource = this.訂購單infoBindingSource;
            this.訂購單編號infoListBox.DisplayMember = "訂購單編號";
            this.訂購單編號infoListBox.ForeColor = System.Drawing.Color.Lime;
            this.訂購單編號infoListBox.FormattingEnabled = true;
            this.訂購單編號infoListBox.ItemHeight = 20;
            this.訂購單編號infoListBox.Location = new System.Drawing.Point(509, 6);
            this.訂購單編號infoListBox.Name = "訂購單編號infoListBox";
            this.訂購單編號infoListBox.Size = new System.Drawing.Size(200, 464);
            this.訂購單編號infoListBox.TabIndex = 71;
            this.訂購單編號infoListBox.ValueMember = "訂購提交";
            this.訂購單編號infoListBox.SelectedIndexChanged += new System.EventHandler(this.訂購單編號infoListBox_SelectedIndexChanged);
            // 
            // 經辦姓名Label1
            // 
            this.經辦姓名Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "經辦姓名", true));
            this.經辦姓名Label1.Location = new System.Drawing.Point(124, 50);
            this.經辦姓名Label1.Name = "經辦姓名Label1";
            this.經辦姓名Label1.Size = new System.Drawing.Size(120, 23);
            this.經辦姓名Label1.TabIndex = 73;
            this.經辦姓名Label1.Text = "label14";
            // 
            // 訂購日期Label1
            // 
            this.訂購日期Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "訂購日期", true));
            this.訂購日期Label1.Location = new System.Drawing.Point(124, 100);
            this.訂購日期Label1.Name = "訂購日期Label1";
            this.訂購日期Label1.Size = new System.Drawing.Size(120, 23);
            this.訂購日期Label1.TabIndex = 75;
            this.訂購日期Label1.Text = "label14";
            // 
            // 訂購狀態Label1
            // 
            this.訂購狀態Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "訂購狀態", true));
            this.訂購狀態Label1.Location = new System.Drawing.Point(124, 150);
            this.訂購狀態Label1.Name = "訂購狀態Label1";
            this.訂購狀態Label1.Size = new System.Drawing.Size(120, 23);
            this.訂購狀態Label1.TabIndex = 77;
            this.訂購狀態Label1.Text = "label14";
            // 
            // 訂購總數量Label1
            // 
            this.訂購總數量Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "訂購總數量", true));
            this.訂購總數量Label1.Location = new System.Drawing.Point(381, 50);
            this.訂購總數量Label1.Name = "訂購總數量Label1";
            this.訂購總數量Label1.Size = new System.Drawing.Size(120, 23);
            this.訂購總數量Label1.TabIndex = 83;
            this.訂購總數量Label1.Text = "label14";
            // 
            // 訂購總金額Label1
            // 
            this.訂購總金額Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "訂購總金額", true));
            this.訂購總金額Label1.Location = new System.Drawing.Point(381, 100);
            this.訂購總金額Label1.Name = "訂購總金額Label1";
            this.訂購總金額Label1.Size = new System.Drawing.Size(120, 23);
            this.訂購總金額Label1.TabIndex = 85;
            this.訂購總金額Label1.Text = "label14";
            // 
            // 訂購品項數量Label1
            // 
            this.訂購品項數量Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "訂購品項數量", true));
            this.訂購品項數量Label1.Location = new System.Drawing.Point(381, 150);
            this.訂購品項數量Label1.Name = "訂購品項數量Label1";
            this.訂購品項數量Label1.Size = new System.Drawing.Size(120, 23);
            this.訂購品項數量Label1.TabIndex = 87;
            this.訂購品項數量Label1.Text = "label14";
            // 
            // 訂購人數Label1
            // 
            this.訂購人數Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "訂購人數", true));
            this.訂購人數Label1.Location = new System.Drawing.Point(124, 200);
            this.訂購人數Label1.Name = "訂購人數Label1";
            this.訂購人數Label1.Size = new System.Drawing.Size(120, 23);
            this.訂購人數Label1.TabIndex = 89;
            this.訂購人數Label1.Text = "label14";
            // 
            // 店名Label2
            // 
            this.店名Label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "店名", true));
            this.店名Label2.Location = new System.Drawing.Point(124, 250);
            this.店名Label2.Name = "店名Label2";
            this.店名Label2.Size = new System.Drawing.Size(120, 23);
            this.店名Label2.TabIndex = 93;
            this.店名Label2.Text = "label14";
            // 
            // 電話Label2
            // 
            this.電話Label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "電話", true));
            this.電話Label2.Location = new System.Drawing.Point(124, 300);
            this.電話Label2.Name = "電話Label2";
            this.電話Label2.Size = new System.Drawing.Size(120, 23);
            this.電話Label2.TabIndex = 95;
            this.電話Label2.Text = "label14";
            // 
            // 地址Label2
            // 
            this.地址Label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單infoBindingSource, "地址", true));
            this.地址Label2.Location = new System.Drawing.Point(124, 350);
            this.地址Label2.Name = "地址Label2";
            this.地址Label2.Size = new System.Drawing.Size(240, 60);
            this.地址Label2.TabIndex = 97;
            this.地址Label2.Text = "label14";
            // 
            // 訂購單細項編號ListBox
            // 
            this.訂購單細項編號ListBox.BackColor = System.Drawing.Color.Black;
            this.訂購單細項編號ListBox.DataSource = this.訂購單細項infoBindingSource;
            this.訂購單細項編號ListBox.DisplayMember = "訂購單細項編號";
            this.訂購單細項編號ListBox.ForeColor = System.Drawing.Color.Lime;
            this.訂購單細項編號ListBox.FormattingEnabled = true;
            this.訂購單細項編號ListBox.ItemHeight = 20;
            this.訂購單細項編號ListBox.Location = new System.Drawing.Point(1178, 6);
            this.訂購單細項編號ListBox.Name = "訂購單細項編號ListBox";
            this.訂購單細項編號ListBox.Size = new System.Drawing.Size(200, 464);
            this.訂購單細項編號ListBox.TabIndex = 40;
            this.訂購單細項編號ListBox.ValueMember = "訂購單細項編號";
            this.訂購單細項編號ListBox.SelectedIndexChanged += new System.EventHandler(this.訂購單細項編號ListBox_SelectedIndexChanged);
            // 
            // 姓名Label1
            // 
            this.姓名Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "姓名", true));
            this.姓名Label1.Location = new System.Drawing.Point(867, 50);
            this.姓名Label1.Name = "姓名Label1";
            this.姓名Label1.Size = new System.Drawing.Size(120, 23);
            this.姓名Label1.TabIndex = 46;
            this.姓名Label1.Text = "label14";
            // 
            // 品名Label2
            // 
            this.品名Label2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "品名", true));
            this.品名Label2.Location = new System.Drawing.Point(867, 100);
            this.品名Label2.Name = "品名Label2";
            this.品名Label2.Size = new System.Drawing.Size(300, 23);
            this.品名Label2.TabIndex = 50;
            this.品名Label2.Text = "label14";
            // 
            // 訂購時間Label3
            // 
            this.訂購時間Label3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "訂購時間", true));
            this.訂購時間Label3.Location = new System.Drawing.Point(867, 250);
            this.訂購時間Label3.Name = "訂購時間Label3";
            this.訂購時間Label3.Size = new System.Drawing.Size(264, 23);
            this.訂購時間Label3.TabIndex = 64;
            this.訂購時間Label3.Text = "label14";
            // 
            // 小計Label1
            // 
            this.小計Label1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購單細項infoBindingSource, "小計", true));
            this.小計Label1.Location = new System.Drawing.Point(867, 350);
            this.小計Label1.Name = "小計Label1";
            this.小計Label1.Size = new System.Drawing.Size(120, 23);
            this.小計Label1.TabIndex = 70;
            this.小計Label1.Text = "label14";
            // 
            // 細項付款確認CheckBox
            // 
            this.細項付款確認CheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.訂購單細項infoBindingSource, "細項付款確認", true));
            this.細項付款確認CheckBox.Location = new System.Drawing.Point(829, 300);
            this.細項付款確認CheckBox.Name = "細項付款確認CheckBox";
            this.細項付款確認CheckBox.Size = new System.Drawing.Size(22, 14);
            this.細項付款確認CheckBox.TabIndex = 103;
            this.細項付款確認CheckBox.Text = "checkBox1";
            this.細項付款確認CheckBox.UseVisualStyleBackColor = true;
            // 
            // tabPage_menu
            // 
            this.tabPage_menu.AutoScroll = true;
            this.tabPage_menu.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage_menu.Controls.Add(label12);
            this.tabPage_menu.Controls.Add(this.button_orderadd);
            this.tabPage_menu.Controls.Add(label13);
            this.tabPage_menu.Controls.Add(this.TB_ordercount);
            this.tabPage_menu.Controls.Add(this.菜色圖片TextBox);
            this.tabPage_menu.Controls.Add(this.TB_menuCS);
            this.tabPage_menu.Controls.Add(this.品名TextBox);
            this.tabPage_menu.Controls.Add(this.單價TextBox);
            this.tabPage_menu.Controls.Add(this.供應限制TextBox);
            this.tabPage_menu.Controls.Add(this.備註TextBox1);
            this.tabPage_menu.Controls.Add(this.LB_menushotlist);
            this.tabPage_menu.Controls.Add(this.菜色圖片Label);
            this.tabPage_menu.Controls.Add(this.PIC_menu);
            this.tabPage_menu.Controls.Add(this.label11);
            this.tabPage_menu.Controls.Add(this.button_menucls);
            this.tabPage_menu.Controls.Add(this.button_menudle);
            this.tabPage_menu.Controls.Add(this.button_menuupdata);
            this.tabPage_menu.Controls.Add(this.button_menuins);
            this.tabPage_menu.Controls.Add(this.LB_menulist);
            this.tabPage_menu.Controls.Add(label10);
            this.tabPage_menu.Controls.Add(品名編號Label);
            this.tabPage_menu.Controls.Add(品名Label);
            this.tabPage_menu.Controls.Add(單價Label);
            this.tabPage_menu.Controls.Add(店家編號Label1);
            this.tabPage_menu.Controls.Add(供應限制Label);
            this.tabPage_menu.Controls.Add(備註Label1);
            this.tabPage_menu.Controls.Add(this.店名Label3);
            this.tabPage_menu.Controls.Add(this.LB_訂購單未提交);
            this.tabPage_menu.Controls.Add(this.訂購單編號ListBox);
            this.tabPage_menu.Location = new System.Drawing.Point(4, 29);
            this.tabPage_menu.Name = "tabPage_menu";
            this.tabPage_menu.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_menu.Size = new System.Drawing.Size(1384, 494);
            this.tabPage_menu.TabIndex = 3;
            this.tabPage_menu.Text = "菜單管理";
            // 
            // button_orderadd
            // 
            this.button_orderadd.BackColor = System.Drawing.Color.Blue;
            this.button_orderadd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_orderadd.Location = new System.Drawing.Point(1042, 422);
            this.button_orderadd.Name = "button_orderadd";
            this.button_orderadd.Size = new System.Drawing.Size(130, 50);
            this.button_orderadd.TabIndex = 61;
            this.button_orderadd.Text = "訂購餐點";
            this.button_orderadd.UseVisualStyleBackColor = false;
            this.button_orderadd.Click += new System.EventHandler(this.button_orderadd_Click);
            // 
            // TB_ordercount
            // 
            this.TB_ordercount.Location = new System.Drawing.Point(1042, 388);
            this.TB_ordercount.Name = "TB_ordercount";
            this.TB_ordercount.Size = new System.Drawing.Size(128, 29);
            this.TB_ordercount.TabIndex = 60;
            this.TB_ordercount.Text = "1";
            this.TB_ordercount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_KeyPress);
            // 
            // 菜色圖片TextBox
            // 
            this.菜色圖片TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "菜色圖片", true));
            this.菜色圖片TextBox.Location = new System.Drawing.Point(132, 440);
            this.菜色圖片TextBox.Name = "菜色圖片TextBox";
            this.菜色圖片TextBox.Size = new System.Drawing.Size(400, 29);
            this.菜色圖片TextBox.TabIndex = 50;
            this.菜色圖片TextBox.TextChanged += new System.EventHandler(this.菜單圖片TextBox_TextChanged);
            // 
            // TB_menuCS
            // 
            this.TB_menuCS.Location = new System.Drawing.Point(1042, 28);
            this.TB_menuCS.Name = "TB_menuCS";
            this.TB_menuCS.Size = new System.Drawing.Size(130, 29);
            this.TB_menuCS.TabIndex = 46;
            this.TB_menuCS.TextChanged += new System.EventHandler(this.TB_menuCS_TextChanged);
            this.TB_menuCS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TB_menuCS_TextChanged);
            // 
            // 品名TextBox
            // 
            this.品名TextBox.AcceptsReturn = true;
            this.品名TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "品名", true));
            this.品名TextBox.Location = new System.Drawing.Point(130, 73);
            this.品名TextBox.Multiline = true;
            this.品名TextBox.Name = "品名TextBox";
            this.品名TextBox.Size = new System.Drawing.Size(400, 70);
            this.品名TextBox.TabIndex = 3;
            // 
            // 單價TextBox
            // 
            this.單價TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "單價", true));
            this.單價TextBox.Location = new System.Drawing.Point(130, 150);
            this.單價TextBox.Name = "單價TextBox";
            this.單價TextBox.Size = new System.Drawing.Size(400, 29);
            this.單價TextBox.TabIndex = 5;
            this.單價TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_KeyPress);
            // 
            // 供應限制TextBox
            // 
            this.供應限制TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "供應限制", true));
            this.供應限制TextBox.Location = new System.Drawing.Point(130, 250);
            this.供應限制TextBox.Name = "供應限制TextBox";
            this.供應限制TextBox.Size = new System.Drawing.Size(400, 29);
            this.供應限制TextBox.TabIndex = 9;
            // 
            // 備註TextBox1
            // 
            this.備註TextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "備註", true));
            this.備註TextBox1.Location = new System.Drawing.Point(130, 300);
            this.備註TextBox1.Multiline = true;
            this.備註TextBox1.Name = "備註TextBox1";
            this.備註TextBox1.Size = new System.Drawing.Size(400, 130);
            this.備註TextBox1.TabIndex = 15;
            // 
            // LB_menushotlist
            // 
            this.LB_menushotlist.BackColor = System.Drawing.Color.Black;
            this.LB_menushotlist.DataSource = this.店家BindingSource;
            this.LB_menushotlist.DisplayMember = "店名";
            this.LB_menushotlist.ForeColor = System.Drawing.Color.Lime;
            this.LB_menushotlist.FormattingEnabled = true;
            this.LB_menushotlist.ItemHeight = 20;
            this.LB_menushotlist.Location = new System.Drawing.Point(834, 6);
            this.LB_menushotlist.Name = "LB_menushotlist";
            this.LB_menushotlist.Size = new System.Drawing.Size(200, 464);
            this.LB_menushotlist.TabIndex = 58;
            this.LB_menushotlist.ValueMember = "店家編號";
            this.LB_menushotlist.Click += new System.EventHandler(this.LB_menushotlist_Click);
            this.LB_menushotlist.DoubleClick += new System.EventHandler(this.LB_menushotlist_DoubleClick);
            // 
            // 菜色圖片Label
            // 
            this.菜色圖片Label.AutoSize = true;
            this.菜色圖片Label.Location = new System.Drawing.Point(38, 443);
            this.菜色圖片Label.Name = "菜色圖片Label";
            this.菜色圖片Label.Size = new System.Drawing.Size(77, 20);
            this.菜色圖片Label.TabIndex = 49;
            this.菜色圖片Label.Text = "菜色圖片:";
            // 
            // PIC_menu
            // 
            this.PIC_menu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PIC_menu.Location = new System.Drawing.Point(538, 73);
            this.PIC_menu.Name = "PIC_menu";
            this.PIC_menu.Size = new System.Drawing.Size(290, 285);
            this.PIC_menu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PIC_menu.TabIndex = 48;
            this.PIC_menu.TabStop = false;
            this.PIC_menu.DoubleClick += new System.EventHandler(this.PIC_menu_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1040, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 20);
            this.label11.TabIndex = 47;
            this.label11.Text = "搜尋品名";
            // 
            // button_menucls
            // 
            this.button_menucls.BackColor = System.Drawing.Color.DarkOrange;
            this.button_menucls.Location = new System.Drawing.Point(1042, 70);
            this.button_menucls.Name = "button_menucls";
            this.button_menucls.Size = new System.Drawing.Size(130, 50);
            this.button_menucls.TabIndex = 45;
            this.button_menucls.Text = "資料欄位清空";
            this.button_menucls.UseVisualStyleBackColor = false;
            this.button_menucls.Click += new System.EventHandler(this.button_menucls_Click);
            // 
            // button_menudle
            // 
            this.button_menudle.BackColor = System.Drawing.Color.Red;
            this.button_menudle.ForeColor = System.Drawing.Color.Yellow;
            this.button_menudle.Location = new System.Drawing.Point(1042, 295);
            this.button_menudle.Name = "button_menudle";
            this.button_menudle.Size = new System.Drawing.Size(130, 50);
            this.button_menudle.TabIndex = 44;
            this.button_menudle.Text = "菜單資料刪除";
            this.button_menudle.UseVisualStyleBackColor = false;
            this.button_menudle.Click += new System.EventHandler(this.button_menudle_Click);
            // 
            // button_menuupdata
            // 
            this.button_menuupdata.BackColor = System.Drawing.Color.Cyan;
            this.button_menuupdata.ForeColor = System.Drawing.Color.Purple;
            this.button_menuupdata.Location = new System.Drawing.Point(1042, 220);
            this.button_menuupdata.Name = "button_menuupdata";
            this.button_menuupdata.Size = new System.Drawing.Size(130, 50);
            this.button_menuupdata.TabIndex = 43;
            this.button_menuupdata.Text = "菜單資料修改";
            this.button_menuupdata.UseVisualStyleBackColor = false;
            this.button_menuupdata.Click += new System.EventHandler(this.button_menuupdata_Click);
            // 
            // button_menuins
            // 
            this.button_menuins.BackColor = System.Drawing.Color.Blue;
            this.button_menuins.ForeColor = System.Drawing.Color.White;
            this.button_menuins.Location = new System.Drawing.Point(1042, 145);
            this.button_menuins.Name = "button_menuins";
            this.button_menuins.Size = new System.Drawing.Size(130, 50);
            this.button_menuins.TabIndex = 42;
            this.button_menuins.Text = "菜單資料新增";
            this.button_menuins.UseVisualStyleBackColor = false;
            this.button_menuins.Click += new System.EventHandler(this.button_menuins_Click);
            // 
            // LB_menulist
            // 
            this.LB_menulist.BackColor = System.Drawing.Color.Black;
            this.LB_menulist.DataSource = this.菜單infoBindingSource;
            this.LB_menulist.DisplayMember = "品名";
            this.LB_menulist.ForeColor = System.Drawing.Color.Lime;
            this.LB_menulist.FormattingEnabled = true;
            this.LB_menulist.ItemHeight = 20;
            this.LB_menulist.Location = new System.Drawing.Point(1178, 6);
            this.LB_menulist.Name = "LB_menulist";
            this.LB_menulist.Size = new System.Drawing.Size(200, 464);
            this.LB_menulist.TabIndex = 41;
            this.LB_menulist.ValueMember = "品名編號";
            this.LB_menulist.SelectedIndexChanged += new System.EventHandler(this.LB_menulist_SelectedIndexChanged);
            this.LB_menulist.SelectedValueChanged += new System.EventHandler(this.LB_menulist_SelectedIndexChanged);
            // 
            // 店名Label3
            // 
            this.店名Label3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.菜單infoBindingSource, "店名", true));
            this.店名Label3.Location = new System.Drawing.Point(128, 200);
            this.店名Label3.Name = "店名Label3";
            this.店名Label3.Size = new System.Drawing.Size(100, 23);
            this.店名Label3.TabIndex = 55;
            this.店名Label3.Text = "label13";
            this.店名Label3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.店名Label3_DoubleClick);
            // 
            // LB_訂購單未提交
            // 
            this.LB_訂購單未提交.DataSource = this.訂購單infoBindingSource2;
            this.LB_訂購單未提交.DisplayMember = "訂購日期";
            this.LB_訂購單未提交.FormattingEnabled = true;
            this.LB_訂購單未提交.ItemHeight = 20;
            this.LB_訂購單未提交.Location = new System.Drawing.Point(884, 314);
            this.LB_訂購單未提交.Name = "LB_訂購單未提交";
            this.LB_訂購單未提交.Size = new System.Drawing.Size(120, 84);
            this.LB_訂購單未提交.TabIndex = 100;
            this.LB_訂購單未提交.ValueMember = "訂購單編號";
            // 
            // 訂購單編號ListBox
            // 
            this.訂購單編號ListBox.DataSource = this.訂購單BindingSource;
            this.訂購單編號ListBox.DisplayMember = "訂購單編號";
            this.訂購單編號ListBox.FormattingEnabled = true;
            this.訂購單編號ListBox.ItemHeight = 20;
            this.訂購單編號ListBox.Location = new System.Drawing.Point(884, 223);
            this.訂購單編號ListBox.Name = "訂購單編號ListBox";
            this.訂購單編號ListBox.Size = new System.Drawing.Size(120, 24);
            this.訂購單編號ListBox.TabIndex = 99;
            this.訂購單編號ListBox.ValueMember = "訂購單編號";
            // 
            // tabPage_shop
            // 
            this.tabPage_shop.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage_shop.Controls.Add(label14);
            this.tabPage_shop.Controls.Add(this.label9);
            this.tabPage_shop.Controls.Add(this.TB_shopSC);
            this.tabPage_shop.Controls.Add(this.店名TextBox);
            this.tabPage_shop.Controls.Add(this.電話TextBox);
            this.tabPage_shop.Controls.Add(this.地址TextBox);
            this.tabPage_shop.Controls.Add(this.備註TextBox);
            this.tabPage_shop.Controls.Add(this.TB_shopTBcls);
            this.tabPage_shop.Controls.Add(this.button_shopdel);
            this.tabPage_shop.Controls.Add(this.button_shopupdata);
            this.tabPage_shop.Controls.Add(this.button_shopins);
            this.tabPage_shop.Controls.Add(this.LB_shoplist);
            this.tabPage_shop.Controls.Add(LAB_shopid);
            this.tabPage_shop.Controls.Add(店家編號Label);
            this.tabPage_shop.Controls.Add(店名Label);
            this.tabPage_shop.Controls.Add(電話Label);
            this.tabPage_shop.Controls.Add(地址Label);
            this.tabPage_shop.Controls.Add(備註Label);
            this.tabPage_shop.Location = new System.Drawing.Point(4, 29);
            this.tabPage_shop.Name = "tabPage_shop";
            this.tabPage_shop.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_shop.Size = new System.Drawing.Size(1384, 494);
            this.tabPage_shop.TabIndex = 1;
            this.tabPage_shop.Text = "餐廳管理";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1040, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 20);
            this.label9.TabIndex = 40;
            this.label9.Text = "搜尋餐廳";
            // 
            // TB_shopSC
            // 
            this.TB_shopSC.Location = new System.Drawing.Point(1042, 28);
            this.TB_shopSC.Name = "TB_shopSC";
            this.TB_shopSC.Size = new System.Drawing.Size(130, 29);
            this.TB_shopSC.TabIndex = 39;
            this.TB_shopSC.TextChanged += new System.EventHandler(this.TB_shopSC_TextChanged);
            // 
            // 店名TextBox
            // 
            this.店名TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.店家BindingSource, "店名", true));
            this.店名TextBox.Location = new System.Drawing.Point(130, 100);
            this.店名TextBox.Name = "店名TextBox";
            this.店名TextBox.Size = new System.Drawing.Size(400, 29);
            this.店名TextBox.TabIndex = 3;
            // 
            // 電話TextBox
            // 
            this.電話TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.店家BindingSource, "電話", true));
            this.電話TextBox.Location = new System.Drawing.Point(130, 150);
            this.電話TextBox.Name = "電話TextBox";
            this.電話TextBox.Size = new System.Drawing.Size(400, 29);
            this.電話TextBox.TabIndex = 5;
            // 
            // 地址TextBox
            // 
            this.地址TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.店家BindingSource, "地址", true));
            this.地址TextBox.Location = new System.Drawing.Point(130, 200);
            this.地址TextBox.Name = "地址TextBox";
            this.地址TextBox.Size = new System.Drawing.Size(400, 29);
            this.地址TextBox.TabIndex = 7;
            // 
            // 備註TextBox
            // 
            this.備註TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.店家BindingSource, "備註", true));
            this.備註TextBox.Location = new System.Drawing.Point(130, 250);
            this.備註TextBox.Multiline = true;
            this.備註TextBox.Name = "備註TextBox";
            this.備註TextBox.Size = new System.Drawing.Size(400, 150);
            this.備註TextBox.TabIndex = 11;
            // 
            // TB_shopTBcls
            // 
            this.TB_shopTBcls.BackColor = System.Drawing.Color.DarkOrange;
            this.TB_shopTBcls.Location = new System.Drawing.Point(1042, 70);
            this.TB_shopTBcls.Name = "TB_shopTBcls";
            this.TB_shopTBcls.Size = new System.Drawing.Size(130, 50);
            this.TB_shopTBcls.TabIndex = 38;
            this.TB_shopTBcls.Text = "資料欄位清空";
            this.TB_shopTBcls.UseVisualStyleBackColor = false;
            this.TB_shopTBcls.Click += new System.EventHandler(this.TB_shopTBcls_Click);
            // 
            // button_shopdel
            // 
            this.button_shopdel.BackColor = System.Drawing.Color.Red;
            this.button_shopdel.ForeColor = System.Drawing.Color.Yellow;
            this.button_shopdel.Location = new System.Drawing.Point(1042, 295);
            this.button_shopdel.Name = "button_shopdel";
            this.button_shopdel.Size = new System.Drawing.Size(130, 50);
            this.button_shopdel.TabIndex = 37;
            this.button_shopdel.Text = "餐廳資料刪除";
            this.button_shopdel.UseVisualStyleBackColor = false;
            this.button_shopdel.Click += new System.EventHandler(this.button_shopdel_Click);
            // 
            // button_shopupdata
            // 
            this.button_shopupdata.BackColor = System.Drawing.Color.Cyan;
            this.button_shopupdata.ForeColor = System.Drawing.Color.Purple;
            this.button_shopupdata.Location = new System.Drawing.Point(1042, 220);
            this.button_shopupdata.Name = "button_shopupdata";
            this.button_shopupdata.Size = new System.Drawing.Size(130, 50);
            this.button_shopupdata.TabIndex = 36;
            this.button_shopupdata.Text = "餐廳資料修改";
            this.button_shopupdata.UseVisualStyleBackColor = false;
            this.button_shopupdata.Click += new System.EventHandler(this.button_shopupdata_Click);
            // 
            // button_shopins
            // 
            this.button_shopins.BackColor = System.Drawing.Color.Blue;
            this.button_shopins.ForeColor = System.Drawing.Color.White;
            this.button_shopins.Location = new System.Drawing.Point(1042, 145);
            this.button_shopins.Name = "button_shopins";
            this.button_shopins.Size = new System.Drawing.Size(130, 50);
            this.button_shopins.TabIndex = 35;
            this.button_shopins.Text = "餐廳資料新增";
            this.button_shopins.UseVisualStyleBackColor = false;
            this.button_shopins.Click += new System.EventHandler(this.button_shopins_Click);
            // 
            // LB_shoplist
            // 
            this.LB_shoplist.BackColor = System.Drawing.Color.Black;
            this.LB_shoplist.DataSource = this.店家BindingSource;
            this.LB_shoplist.DisplayMember = "店名";
            this.LB_shoplist.ForeColor = System.Drawing.Color.Lime;
            this.LB_shoplist.FormattingEnabled = true;
            this.LB_shoplist.ItemHeight = 20;
            this.LB_shoplist.Location = new System.Drawing.Point(1178, 6);
            this.LB_shoplist.Name = "LB_shoplist";
            this.LB_shoplist.Size = new System.Drawing.Size(200, 464);
            this.LB_shoplist.TabIndex = 34;
            this.LB_shoplist.ValueMember = "店家編號";
            this.LB_shoplist.SelectedIndexChanged += new System.EventHandler(this.LB_shoplist_SelectedIndexChanged);
            this.LB_shoplist.DoubleClick += new System.EventHandler(this.LB_shoplist_DoubleClick);
            // 
            // tabPage_member
            // 
            this.tabPage_member.AutoScroll = true;
            this.tabPage_member.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage_member.Controls.Add(label15);
            this.tabPage_member.Controls.Add(this.label8);
            this.tabPage_member.Controls.Add(this.TB_userSC2);
            this.tabPage_member.Controls.Add(this.TB_userremark);
            this.tabPage_member.Controls.Add(this.TB_userclassroom);
            this.tabPage_member.Controls.Add(this.TB_useridentity);
            this.tabPage_member.Controls.Add(this.TB_usertel);
            this.tabPage_member.Controls.Add(this.TB_username);
            this.tabPage_member.Controls.Add(LAB_userid);
            this.tabPage_member.Controls.Add(this.TB_userTBcls);
            this.tabPage_member.Controls.Add(this.label7);
            this.tabPage_member.Controls.Add(this.label6);
            this.tabPage_member.Controls.Add(this.label5);
            this.tabPage_member.Controls.Add(this.label4);
            this.tabPage_member.Controls.Add(this.label3);
            this.tabPage_member.Controls.Add(this.LB_userid);
            this.tabPage_member.Controls.Add(this.button_useridel);
            this.tabPage_member.Controls.Add(this.button_userupdata);
            this.tabPage_member.Controls.Add(this.button_userins);
            this.tabPage_member.Controls.Add(this.LB_userlist);
            this.tabPage_member.Location = new System.Drawing.Point(4, 29);
            this.tabPage_member.Name = "tabPage_member";
            this.tabPage_member.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_member.Size = new System.Drawing.Size(1384, 494);
            this.tabPage_member.TabIndex = 0;
            this.tabPage_member.Text = "成員管理";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(1038, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 20);
            this.label8.TabIndex = 34;
            this.label8.Text = "搜尋姓名";
            // 
            // TB_userSC2
            // 
            this.TB_userSC2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_userSC2.Location = new System.Drawing.Point(1042, 28);
            this.TB_userSC2.Name = "TB_userSC2";
            this.TB_userSC2.Size = new System.Drawing.Size(130, 29);
            this.TB_userSC2.TabIndex = 33;
            this.TB_userSC2.TextChanged += new System.EventHandler(this.TB_userSC2_TextChanged);
            // 
            // TB_userremark
            // 
            this.TB_userremark.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購人BindingSource, "備註", true));
            this.TB_userremark.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_userremark.Location = new System.Drawing.Point(130, 300);
            this.TB_userremark.Multiline = true;
            this.TB_userremark.Name = "TB_userremark";
            this.TB_userremark.Size = new System.Drawing.Size(400, 150);
            this.TB_userremark.TabIndex = 29;
            // 
            // TB_userclassroom
            // 
            this.TB_userclassroom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購人BindingSource, "上課地點", true));
            this.TB_userclassroom.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_userclassroom.Location = new System.Drawing.Point(130, 250);
            this.TB_userclassroom.Name = "TB_userclassroom";
            this.TB_userclassroom.Size = new System.Drawing.Size(400, 29);
            this.TB_userclassroom.TabIndex = 28;
            // 
            // TB_useridentity
            // 
            this.TB_useridentity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購人BindingSource, "身分別", true));
            this.TB_useridentity.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_useridentity.Location = new System.Drawing.Point(130, 200);
            this.TB_useridentity.Name = "TB_useridentity";
            this.TB_useridentity.Size = new System.Drawing.Size(400, 29);
            this.TB_useridentity.TabIndex = 27;
            // 
            // TB_usertel
            // 
            this.TB_usertel.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購人BindingSource, "電話", true));
            this.TB_usertel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_usertel.Location = new System.Drawing.Point(130, 150);
            this.TB_usertel.Name = "TB_usertel";
            this.TB_usertel.Size = new System.Drawing.Size(400, 29);
            this.TB_usertel.TabIndex = 26;
            // 
            // TB_username
            // 
            this.TB_username.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.訂購人BindingSource, "姓名", true));
            this.TB_username.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_username.Location = new System.Drawing.Point(130, 100);
            this.TB_username.Name = "TB_username";
            this.TB_username.Size = new System.Drawing.Size(400, 29);
            this.TB_username.TabIndex = 25;
            // 
            // TB_userTBcls
            // 
            this.TB_userTBcls.BackColor = System.Drawing.Color.DarkOrange;
            this.TB_userTBcls.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TB_userTBcls.Location = new System.Drawing.Point(1042, 70);
            this.TB_userTBcls.Name = "TB_userTBcls";
            this.TB_userTBcls.Size = new System.Drawing.Size(130, 50);
            this.TB_userTBcls.TabIndex = 30;
            this.TB_userTBcls.Text = "資料欄位清空";
            this.TB_userTBcls.UseVisualStyleBackColor = false;
            this.TB_userTBcls.Click += new System.EventHandler(this.TB_userTBcls_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(40, 300);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 20);
            this.label7.TabIndex = 24;
            this.label7.Text = "備註:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(40, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 20);
            this.label6.TabIndex = 23;
            this.label6.Text = "上課地點:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(40, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "身分別:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(40, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "電話:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(40, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "姓名:";
            // 
            // LB_userid
            // 
            this.LB_userid.AutoSize = true;
            this.LB_userid.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LB_userid.Location = new System.Drawing.Point(40, 50);
            this.LB_userid.Name = "LB_userid";
            this.LB_userid.Size = new System.Drawing.Size(77, 20);
            this.LB_userid.TabIndex = 19;
            this.LB_userid.Text = "成員編號:";
            // 
            // button_useridel
            // 
            this.button_useridel.BackColor = System.Drawing.Color.Red;
            this.button_useridel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_useridel.ForeColor = System.Drawing.Color.Yellow;
            this.button_useridel.Location = new System.Drawing.Point(1042, 295);
            this.button_useridel.Name = "button_useridel";
            this.button_useridel.Size = new System.Drawing.Size(130, 50);
            this.button_useridel.TabIndex = 12;
            this.button_useridel.Text = "成員資料刪除";
            this.button_useridel.UseVisualStyleBackColor = false;
            this.button_useridel.Click += new System.EventHandler(this.button_useridel_Click);
            // 
            // button_userupdata
            // 
            this.button_userupdata.BackColor = System.Drawing.Color.Cyan;
            this.button_userupdata.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_userupdata.ForeColor = System.Drawing.Color.Purple;
            this.button_userupdata.Location = new System.Drawing.Point(1042, 220);
            this.button_userupdata.Name = "button_userupdata";
            this.button_userupdata.Size = new System.Drawing.Size(130, 50);
            this.button_userupdata.TabIndex = 11;
            this.button_userupdata.Text = "成員資料修改";
            this.button_userupdata.UseVisualStyleBackColor = false;
            this.button_userupdata.Click += new System.EventHandler(this.button_userupdata_Click);
            // 
            // button_userins
            // 
            this.button_userins.BackColor = System.Drawing.Color.Blue;
            this.button_userins.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_userins.ForeColor = System.Drawing.Color.White;
            this.button_userins.Location = new System.Drawing.Point(1042, 145);
            this.button_userins.Name = "button_userins";
            this.button_userins.Size = new System.Drawing.Size(130, 50);
            this.button_userins.TabIndex = 10;
            this.button_userins.Text = "成員資料新增";
            this.button_userins.UseVisualStyleBackColor = false;
            this.button_userins.Click += new System.EventHandler(this.button_userins_Click);
            // 
            // LB_userlist
            // 
            this.LB_userlist.BackColor = System.Drawing.Color.Black;
            this.LB_userlist.DataSource = this.訂購人BindingSource;
            this.LB_userlist.DisplayMember = "姓名";
            this.LB_userlist.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LB_userlist.ForeColor = System.Drawing.Color.Lime;
            this.LB_userlist.FormattingEnabled = true;
            this.LB_userlist.ItemHeight = 20;
            this.LB_userlist.Location = new System.Drawing.Point(1178, 6);
            this.LB_userlist.Name = "LB_userlist";
            this.LB_userlist.Size = new System.Drawing.Size(200, 464);
            this.LB_userlist.TabIndex = 9;
            this.LB_userlist.ValueMember = "訂購人編號";
            this.LB_userlist.SelectedIndexChanged += new System.EventHandler(this.listBox_userlist_SelectedIndexChanged);
            // 
            // tabControl_iii
            // 
            this.tabControl_iii.Controls.Add(this.tabPage_member);
            this.tabControl_iii.Controls.Add(this.tabPage_shop);
            this.tabControl_iii.Controls.Add(this.tabPage_menu);
            this.tabControl_iii.Controls.Add(this.tabPage_orders);
            this.tabControl_iii.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl_iii.Location = new System.Drawing.Point(12, 32);
            this.tabControl_iii.Name = "tabControl_iii";
            this.tabControl_iii.SelectedIndex = 0;
            this.tabControl_iii.Size = new System.Drawing.Size(1392, 527);
            this.tabControl_iii.TabIndex = 3;
            // 
            // TB_userlistSC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1405, 689);
            this.Controls.Add(this.tabControl_iii);
            this.Controls.Add(this.TB_uselog);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TB_userSC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_login);
            this.Controls.Add(this.LB_user);
            this.Name = "TB_userlistSC";
            this.Text = "iii餐飲訂購";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.菜單infoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iii02_01DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.店家BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購人BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單細項infoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單infoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單infoBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.餐廳BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.訂購單infoBindingSource1)).EndInit();
            this.tabPage_orders.ResumeLayout(false);
            this.tabPage_orders.PerformLayout();
            this.tabPage_menu.ResumeLayout(false);
            this.tabPage_menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PIC_menu)).EndInit();
            this.tabPage_shop.ResumeLayout(false);
            this.tabPage_shop.PerformLayout();
            this.tabPage_member.ResumeLayout(false);
            this.tabPage_member.PerformLayout();
            this.tabControl_iii.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox LB_user;
        private iii02_01DataSet iii02_01DataSet;
        private iii02_01DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingSource 訂購人BindingSource;
        private iii02_01DataSetTableAdapters.訂購人TableAdapter 訂購人TableAdapter;
        private System.Windows.Forms.BindingSource 店家BindingSource;
        private iii02_01DataSetTableAdapters.店家TableAdapter 店家TableAdapter;
        private System.Windows.Forms.TextBox TB_userSC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource 菜單infoBindingSource;
        private iii02_01DataSetTableAdapters.菜單infoTableAdapter 菜單infoTableAdapter;
        private System.Windows.Forms.BindingSource 餐廳BindingSource;
        private iii02_01DataSetTableAdapters.餐廳TableAdapter 餐廳TableAdapter;
        private System.Windows.Forms.TextBox TB_uselog;
        private System.Windows.Forms.BindingSource 訂購單BindingSource;
        private iii02_01DataSetTableAdapters.訂購單TableAdapter 訂購單TableAdapter;
        private System.Windows.Forms.BindingSource 訂購單細項infoBindingSource;
        private iii02_01DataSetTableAdapters.訂購單細項infoTableAdapter 訂購單細項infoTableAdapter;
        private System.Windows.Forms.BindingSource 訂購單infoBindingSource;
        private iii02_01DataSetTableAdapters.訂購單infoTableAdapter 訂購單infoTableAdapter;
        private System.Windows.Forms.BindingSource 訂購單infoBindingSource1;
        private System.Windows.Forms.BindingSource 訂購單infoBindingSource2;
        private System.Windows.Forms.TabPage tabPage_orders;
        private System.Windows.Forms.Label 訂購數量Label2;
        private System.Windows.Forms.Label 單價Label2;
        private System.Windows.Forms.Button button_notpay;
        private System.Windows.Forms.Label 細項付款確認Label;
        private System.Windows.Forms.Button button_subdel;
        private System.Windows.Forms.Button button_subpaycheck;
        private System.Windows.Forms.Button button_orderdel;
        private System.Windows.Forms.Button button_orderclose;
        private System.Windows.Forms.ListBox 訂購單編號infoListBox;
        private System.Windows.Forms.Label 經辦姓名Label1;
        private System.Windows.Forms.Label 訂購日期Label1;
        private System.Windows.Forms.Label 訂購狀態Label1;
        private System.Windows.Forms.Label 訂購總數量Label1;
        private System.Windows.Forms.Label 訂購總金額Label1;
        private System.Windows.Forms.Label 訂購品項數量Label1;
        private System.Windows.Forms.Label 訂購人數Label1;
        private System.Windows.Forms.Label 店名Label2;
        private System.Windows.Forms.Label 電話Label2;
        private System.Windows.Forms.Label 地址Label2;
        private System.Windows.Forms.ListBox 訂購單細項編號ListBox;
        private System.Windows.Forms.Label 姓名Label1;
        private System.Windows.Forms.Label 品名Label2;
        private System.Windows.Forms.Label 訂購時間Label3;
        private System.Windows.Forms.Label 小計Label1;
        private System.Windows.Forms.CheckBox 細項付款確認CheckBox;
        private System.Windows.Forms.TabPage tabPage_menu;
        private System.Windows.Forms.Button button_orderadd;
        private System.Windows.Forms.TextBox TB_ordercount;
        private System.Windows.Forms.TextBox 菜色圖片TextBox;
        private System.Windows.Forms.TextBox TB_menuCS;
        private System.Windows.Forms.TextBox 品名TextBox;
        private System.Windows.Forms.TextBox 單價TextBox;
        private System.Windows.Forms.TextBox 供應限制TextBox;
        private System.Windows.Forms.TextBox 備註TextBox1;
        private System.Windows.Forms.ListBox LB_menushotlist;
        private System.Windows.Forms.Label 菜色圖片Label;
        private System.Windows.Forms.PictureBox PIC_menu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_menucls;
        private System.Windows.Forms.Button button_menudle;
        private System.Windows.Forms.Button button_menuupdata;
        private System.Windows.Forms.Button button_menuins;
        private System.Windows.Forms.ListBox LB_menulist;
        private System.Windows.Forms.Label 店名Label3;
        private System.Windows.Forms.ListBox LB_訂購單未提交;
        private System.Windows.Forms.ListBox 訂購單編號ListBox;
        private System.Windows.Forms.TabPage tabPage_shop;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TB_shopSC;
        private System.Windows.Forms.TextBox 店名TextBox;
        private System.Windows.Forms.TextBox 電話TextBox;
        private System.Windows.Forms.TextBox 地址TextBox;
        private System.Windows.Forms.TextBox 備註TextBox;
        private System.Windows.Forms.Button TB_shopTBcls;
        private System.Windows.Forms.Button button_shopdel;
        private System.Windows.Forms.Button button_shopupdata;
        private System.Windows.Forms.Button button_shopins;
        private System.Windows.Forms.ListBox LB_shoplist;
        private System.Windows.Forms.TabPage tabPage_member;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TB_userSC2;
        private System.Windows.Forms.TextBox TB_userremark;
        private System.Windows.Forms.TextBox TB_userclassroom;
        private System.Windows.Forms.TextBox TB_useridentity;
        private System.Windows.Forms.TextBox TB_usertel;
        private System.Windows.Forms.TextBox TB_username;
        private System.Windows.Forms.Button TB_userTBcls;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LB_userid;
        private System.Windows.Forms.Button button_useridel;
        private System.Windows.Forms.Button button_userupdata;
        private System.Windows.Forms.Button button_userins;
        private System.Windows.Forms.ListBox LB_userlist;
        private System.Windows.Forms.TabControl tabControl_iii;
    }
}

